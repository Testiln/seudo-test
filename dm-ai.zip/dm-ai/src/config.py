import os

DEBUG_MODE = True
PROJECT_NAME = "Simulador de modelos de teoria de colas"
PROJECT_TITLE = "AMIA"
VERSION = "1.0"

PROJECT_INFO = (f"Nombre: {PROJECT_NAME}\nVersión: {VERSION}\nAutores: Alberto Mercado Piñeres, Juan Quintero Gonzalez\nGrupo: Simulación Grupo 1 - 2025-01\n\nEsta aplicación procesa enunciados de problemas de \nteoría de colas desde imágenes, extrae parámetros y \nlos prepara para modelos de simulación: M/M/1, M/M/1/K, M/M/s o M/M/s/K.")

# COnfiguración de la ruta del proyecto
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")

# Frases que se utilizan para encontrar oraciones potenciales a contener parametros principales (búsqueda semántica)
FRASES_CLAVE_PARAMETROS = {
    "llegada": [
        # Énfasis en tasa de llegadas
        "tasa de llegada", "la tasa de llegada es", "tasa de llegada de clientes", "tasa de llegada de unidades",
        "tasa media de llegada", "la tasa media de llegada es", "tasa esperada de llegada", "la tasa esperada de llegada es",
        "razón de llegada", "la razón de llegada es", "a razón de llegadas", "llegan a razón de",
        "frecuencia de llegada", "la frecuencia de llegada es", "frecuencia de arribo", "tasa de arribo",
        "llegan clientes a una tasa de", "arriban unidades con una frecuencia de",
        "pacientes se presentan a razón de", "el flujo de llegada es de",
        "llegan en promedio X por Y", "las llegadas ocurren a razón de",
        "se registran llegadas con una tasa de", "arribos por hora", "llegadas por minuto",
        "clientes por hora llegan", "unidades por día entran", "llegan según una distribución de probabilidades de Poisson con media de", "llegan según una distribución de Poisson a razón de",
        "llegan según Poisson a razón de", "llegadas Poisson con media de",
        "tasa de llegadas de Poisson", "proceso de llegada Poisson con tasa",
        "llegan de acuerdo con una distribución de Poisson a razón de",
        "las llegadas siguen una distribución de Poisson con tasa de",
        "la razón de arribo es", "la frecuencia de entrada es", "tasa de entrada",
        "patrón de llegadas", "patrón de arribos",
        "llegan a la clínica de un médico de acuerdo con una distribución de Poisson",
        "los clientes llegan a una tasa de",
        "la tasa esperada de llegada de pacientes es de",

        # Énfasis en tiempo entre llegadas
        "tiempo entre llegadas", "el tiempo entre llegadas es", "tiempo promedio entre llegadas",
        "intervalo promedio entre arribos", "tiempo esperado entre llegadas",
        "tiempo medio entre llegadas", "intervalo de llegada",
        "llega un cliente cada", "los clientes ingresan cada", "unidades arriban cada",
        "se espera que arriben unidades cada",
        "un nuevo pedido entra al sistema cada",
        "un arribo cada", "la entrada de clientes es cada", "tiempo entre arribos de",
        "intervalo entre llegadas exponencial con media de", "tiempo entre llegadas sigue una exponencial",
        "el tiempo entre llegadas sigue una distribución exponencial",
        "tiempo entre llegadas distribuido exponencialmente con media de",
        # Frases más generales del proceso de llegada
        "entran al sistema", "se presentan en la cola", "la llegada de clientes sigue una distribución",
        "llegan según un proceso de Poisson", "las llegadas ocurren", "se registran llegadas",
        "llegan al sistema", "ingresan a la cola", "se espera la llegada de",
        "nuevos pedidos entran", "entrada de pedidos", "se reciben pedidos", "flujo de entrada"
    ],
    "servicio": [
        # Énfasis en tasa de servicio
        "tasa de servicio", "la tasa de servicio es", "tasa de servicio por servidor",
        "tasa media de servicio", "la tasa media de servicio es", "tasa esperada de servicio", "la tasa esperada de servicio es",
        "razón de servicio", "la razón de servicio es", "a razón de servicios", "atiende a razón de",
        "capacidad de atención", "velocidad de servicio", "ritmo de servicio", "tasa de proceso",
        "frecuencia de servicio", "la frecuencia de servicio es", "tasa de atención por servidor",
        "procesa unidades a una tasa de", "el servidor atiende a una tasa de",
        "atiende en promedio X por Y", "clientes atendidos por hora", "unidades procesadas por minuto",
        "frecuencia con que se procesa", "tasa de servicio exponencial",
        "el servicio es Poisson con tasa de", "tasa de servicio del servidor",
        "el servidor puede procesar a una tasa de", "tasa de procesamiento del servidor",

        # Énfasis en tiempo de servicio
        "tiempo de servicio", "el tiempo de servicio es", "tiempo promedio de servicio","tiempo para cruzar es exponencial", "tiempo para atravesar",
        "tiempo esperado de servicio", "la duración del servicio es", "tiempo promedio para atender",
        "tiempo de procesamiento", "el tiempo de procesamiento es",
        "demora en atender", "atiende clientes cada", "se procesan ítems cada",
        "el servidor tarda en procesar", "el tiempo de atención sigue una distribución",
        "tiempo de consulta por paciente", "la duración media del servicio es",
        "tiempo para completar una tarea", "el servicio toma en promedio",
        "tiempo de ocupación del servidor", "tiempo de servicio exponencial con media de",
        "el tiempo de servicio sigue una exponencial de",
        "tiempo de servicio distribuido exponencialmente con media de", "el tiempo de servicio por cliente es exponencial", "el tiempo promedio de servicio por cliente es exponencial", "el tiempo que [...] emplea para realizar [...] es exponencial con media de", "el tiempo que X emplea para Y es exponencial con media de",
        # Frases más generales del proceso de llegada
        "el sistema procesa", "patrón de servicio", "el servidor puede procesar", "capacidad de procesamiento"
    ],
    "servidores": ["número de servidores", "cantidad de cajeros", "puestos de atención", "operarios disponibles", "cuántas máquinas hay", "dispone de servidores", "cantidad de casetas"],
    "capacidad_sistema": ["capacidad del sistema", "tamaño de la cola", "límite de clientes en el sistema", "espacio en la sala de espera", "cuántos caben como máximo", "capacidad de k", "capacidad es de", "capacidad máxima", "rechaza clientes si hay más de", "solo se permiten", "buffer de tamaño"],
    "disciplina_cola": ["disciplina de la cola", "orden de atención", "tipo de cola", "cómo se atiende", "FIFO", "LIFO", "primero en llegar primero en ser servido", "atención por prioridad", "orden de llegada"]
}

# Utilizado para encontrar números escritos en palabras y no númericamente
NUMEROS_EN_PALABRAS_MAP = {
    "cero": 0, "uno": 1, "una vez":1, "dos": 2, "tres": 3, "cuatro": 4, "cinco": 5, 
    "seis": 6, "siete": 7, "ocho": 8, "nueve": 9, "diez": 10, "once": 11, "doce": 12,
    "trece": 13, "catorce": 14, "quince": 15, "dieciséis": 16, "diecisiete": 17,
    "dieciocho": 18, "diecinueve": 19, "veinte": 20, "veintiun": 21, "veintiuno": 21,
    "veintidós": 22, "veintitrés": 23, "veinticuatro": 24, "veinticinco": 25,
    "veintiséis": 26, "veintisiete": 27, "veintiocho": 28, "veintinueve": 29,
    "treinta": 30, "cuarenta": 40, "cincuenta": 50, "sesenta": 60,
    "setenta": 70, "ochenta": 80, "noventa": 90, "cien": 100, "ciento": 100,
}

# Expresiones regulares para encontar números en oraciones
PALABRAS_NUMERO_REGEX = r"(?<!\w)(" + "|".join(NUMEROS_EN_PALABRAS_MAP.keys()) + r")(?!\w)"
DIGITAL_NUMERO_REGEX = r"\b\d+([.,]\d+)?\b"

# Lista con unidades de tiempo soportadas por la IA
unidades_tiempo_singular_list = ["segundo", "minuto", "hora", "día", "semana", "mes", "año"]
unidades_tiempo_plural_list = ["segundos", "minutos", "horas", "días", "semanas", "meses", "años"]

# Lista de entidades para extraccion valor y unidades en oración (incluye servidores y clientes)
entidades_comunes_list = ["cliente", "paciente", "unidad", "ítem", "item", "trabajo", "pedido", "vehículo", "tarea", "consulta", "llamada", "operacion", "evento", "auto", "caja", "persona", "carro", "moto"]

# Palabras claves para detectar servidores en el texto a analizar
keywords_servidor = ["servidor", "cajero", "máquina", "operador", "ventanilla", "puesto", "estación", "médico", "bomba", "doctor", "enfermero", "consultorio", "línea de ensamblaje", "mécanico", "caja", "peluquero", "caseta", "animador", "estacionamiento"]

# Palabras claves para detectar capacidad del sistema/cola
keywords_cap = ["capacidad", "límite", "tamaño", "espacio", "máximo", "sumo", "buffer"] # Referencia a capacidad
keywords_entidad = ["cliente", "persona", "unidad", "auto", "puesto", "elemento", "paciente", "trabajo", "item"] # Referencia a entidad
keywords_lugar_espera = ["cola", "sala de espera", "almacén", "buffer", "linea de espera", "espacio", "carril", "fila"] # Referencia al lugar de espera
keywords_verbos_capacidad = ["caber", "acomodar", "alojar", "contener", "admitir", "soportar", "permitir", "tener"] # Verbos para detectar refencia a capacidad