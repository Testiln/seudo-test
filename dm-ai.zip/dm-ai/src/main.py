import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from tkinter import font as tkFont
import os
import sys
import json
import re
import subprocess

import config

# --- Añadir raíz del proyecto a sys.path y definir PROJECT_ROOT_DIR ---
# (Sin cambios)
script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(script_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)
PROJECT_ROOT_DIR = project_root

# --- Importaciones de módulos ---
# (Sin cambios)
try:
    from PIL import Image, ImageEnhance
except ImportError: messagebox.showerror("Error importación", "Pillow no instalado."); exit()
try:
    import pytesseract
except ImportError: messagebox.showerror("Error importación", "pytesseract no instalado."); exit()
try:
    from docx import Document
except ImportError: messagebox.showerror("Error importación", "python-docx no instalado."); exit()
try:
    from modules import text_extractor, document_generator, image_preprocessor, tesseract_config, calculator
    import ai_nlp
except ImportError as e_mod_user:
    messagebox.showerror("Error Módulos Usuario", f"No se importaron módulos: {e_mod_user}\nVerifique que 'modules/__init__.py' exista y que 'ai_nlp.py' esté en 'src/'."); exit()
except Exception as e_general_import:
    messagebox.showerror("Error de Importación General", f"Ocurrió un error al importar módulos: {e_general_import}"); exit()


# --- Constantes y Globales ---
# (Sin cambios)
tesseract_configurado_ok = False
try:
    tesseract_configurado_ok = tesseract_config.configure_tesseract()
except Exception as e_config_module:
    print(f"ERROR INESPERADO config Tesseract: {e_config_module}")
    messagebox.showerror("Error Configuración", f"Error config Tesseract:\n{e_config_module}")
    tesseract_configurado_ok = False

secciones_info = []
nlp_sistema_listo = False
popup_cargando_actual = None
FONT_FAMILY = "Inter"
popup_cargando_label_widget = None
try:
    default_font_obj = tkFont.nametofont("TkDefaultFont"); DEFAULT_FONT_SIZE = default_font_obj.actual()["size"]
except: DEFAULT_FONT_SIZE = 10
FONT_NORMAL = (FONT_FAMILY, DEFAULT_FONT_SIZE); FONT_BOLD = (FONT_FAMILY, DEFAULT_FONT_SIZE, "bold")
FONT_PLACEHOLDER = (FONT_FAMILY, DEFAULT_FONT_SIZE); FONT_TOGGLE_ARROW = (FONT_FAMILY, DEFAULT_FONT_SIZE + 1)
FONT_TOGGLE_PASO_BOLD = (FONT_FAMILY, DEFAULT_FONT_SIZE + 2, "bold"); FONT_TOGGLE_TITLE_NORMAL = (FONT_FAMILY, DEFAULT_FONT_SIZE + 2)
FONT_MAIN_TITLE = (FONT_FAMILY, DEFAULT_FONT_SIZE + 6, "bold"); FONT_SECTION_HEADER = (FONT_FAMILY, DEFAULT_FONT_SIZE + 2, "bold")
FONT_SUB_HEADER = (FONT_FAMILY, DEFAULT_FONT_SIZE + 1, "bold"); FONT_BUTTON_ACTION_MAIN = (FONT_FAMILY, DEFAULT_FONT_SIZE, "bold")
COLOR_BOTON_ACCION_PRINCIPAL_AZUL = "#0078D4"; COLOR_TEXTO_BOTON_AZUL = "white"
COLOR_BOTON_DESHABILITADO_BG = "#cccccc"; COLOR_BOTON_DESHABILITADO_FG = "#666666"
COLOR_TEXTO_EXITO = "green"; COLOR_TEXTO_ADVERTENCIA = "#cc5500"
COLOR_GRIS_TEXTO_PLACEHOLDER = "#888888"; COLOR_GRIS_TEXTO_SECUNDARIO = "#595959"
COLOR_BOTON_MINIMALISTA_BG = "#f0f0f0"; COLOR_BOTON_MINIMALISTA_FG = "#333333"
COLOR_BOTON_MINIMALISTA_ACTIVE_BG = "#e0e0e0"; COLOR_BOTON_MINIMALISTA_BORDER = "#ababab"
COLOR_HEADER_LOCKED_BG = "#e8e8e8"; COLOR_HEADER_LOCKED_FG = "#a0a0a0"
COLOR_HEADER_ACTIVE_BG = "#e0e0e0"; COLOR_HEADER_ACTIVE_FG = "#333333"
ROOT_BG_COLOR = "#f0f0f0" # Definir color de fondo de root
PLACEHOLDER_INGRESE_VALOR = "Ingrese valor"; PLACEHOLDER_EJ_20 = "Ej: 20"
DEFAULT_RATE_UNITS = ["clientes/hora", "clientes/minuto", "clientes/día", "clientes/segundo", "clientes/mes", "clientes/año"]
DEFAULT_TIME_UNITS = ["minutos", "horas", "segundos", "días", "meses", "años"]
DEFAULT_LAMBDA_UNIT_SELECTION = "clientes/hora" 
DEFAULT_MU_TIME_UNIT_SELECTION = "minutos" 

# --- Funciones para Popup de Carga y Procesamiento (sin cambios) ---
def mostrar_popup_cargando(parent_root, mensaje="Procesando, por favor espere..."):
    global popup_cargando_actual
    if popup_cargando_actual and popup_cargando_actual.winfo_exists():
        try: popup_cargando_actual.destroy()
        except tk.TclError: pass
    popup_cargando_actual = tk.Toplevel(parent_root); popup_cargando_actual.transient(parent_root)
    popup_cargando_actual.grab_set(); popup_cargando_actual.title("Cargando")
    parent_root.update_idletasks(); parent_width = parent_root.winfo_width(); parent_height = parent_root.winfo_height()
    parent_x = parent_root.winfo_x(); parent_y = parent_root.winfo_y()
    popup_width = 300; popup_height = 100
    x = parent_x + (parent_width // 2) - (popup_width // 2); y = parent_y + (parent_height // 2) - (popup_height // 2)
    popup_cargando_actual.geometry(f"{popup_width}x{popup_height}+{x}+{y}"); popup_cargando_actual.resizable(False, False)
    popup_cargando_actual.protocol("WM_DELETE_WINDOW", lambda: None)
    label = ttk.Label(popup_cargando_actual, text=mensaje, font=FONT_NORMAL, anchor="center")
    label.pack(expand=True, fill="both", padx=20, pady=20); parent_root.update_idletasks()
def cerrar_popup_cargando():
    global popup_cargando_actual
    if popup_cargando_actual and popup_cargando_actual.winfo_exists():
        try: popup_cargando_actual.grab_release(); popup_cargando_actual.destroy()
        except tk.TclError: pass
        popup_cargando_actual = None
    if root.winfo_exists(): root.update_idletasks()

def mostrar_popup_opcion_descarga(mensaje_original, comando_descarga_lista, tipo_modelo):
    """
    Muestra un popup que informa sobre un modelo NLP faltante y ofrece descargarlo/reintentar.
    Retorna True si el NLP está listo después de la acción, False en caso contrario.
    """
    global nlp_sistema_listo  # Para actualizar el estado global de NLP

    popup = tk.Toplevel(root)
    popup.title("Problema con Modelo NLP")
    popup.resizable(False, False)
    popup.transient(root)  # Hacerla modal respecto a la ventana principal
    popup.grab_set()  # Capturar eventos

    # Centrar popup (código similar al que usas para otros popups)
    popup_width = 450
    popup_height = 200 + mensaje_original.count('\n') * 15  # Ajustar altura según mensaje
    root.update_idletasks()
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    x = (screen_width // 2) - (popup_width // 2)
    y = (screen_height // 2) - (popup_height // 2)
    popup.geometry(f'{popup_width}x{popup_height}+{x}+{y}')

    ttk.Label(popup, text = mensaje_original, wraplength = popup_width - 40, justify = tk.LEFT,
              padding = (10, 10, 10, 0)).pack(pady = (5, 0), fill = "x", expand = True)

    # Variable para saber si el usuario hizo clic en la acción principal o canceló
    # Esto es para controlar el flujo si el usuario cierra la ventana sin hacer clic
    intento_realizado = tk.BooleanVar(value = False)

    def ejecutar_accion_y_reintentar():
        intento_realizado.set(True)  # Marcar que se intentó una acción
        popup.destroy()  # Cerrar este popup antes de mostrar otros

        descarga_o_intento_valido = False

        if comando_descarga_lista:  # Específico para spaCy con comando de descarga
            # Popup de "Descargando..."
            popup_progreso = tk.Toplevel(root)
            popup_progreso.title("Procesando...")
            popup_progreso.resizable(False, False)
            popup_progreso.transient(root)
            popup_progreso.grab_set()

            # Centrar popup de progreso
            prog_width, prog_height = 350, 120
            x_prog = (screen_width // 2) - (prog_width // 2)
            y_prog = (screen_height // 2) - (prog_height // 2)
            popup_progreso.geometry(f'{prog_width}x{prog_height}+{x_prog}+{y_prog}')

            comando_str = ' '.join(comando_descarga_lista)
            ttk.Label(popup_progreso,
                      text = f"Ejecutando:\n{comando_str}\n\nEsto podría tardar unos momentos.\nPor favor, espere...",
                      wraplength = prog_width - 20, justify = "center", padding = 10).pack(expand = True, fill = "both")
            popup_progreso.update()

            try:
                startupinfo = None
                if os.name == 'nt':  # Para Windows, ocultar la ventana de consola
                    startupinfo = subprocess.STARTUPINFO()
                    startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                    startupinfo.wShowWindow = subprocess.SW_HIDE

                # Ejecutar el comando de descarga
                proceso = subprocess.run(comando_descarga_lista, capture_output = True, text = True, encoding = 'utf-8',
                                         errors = 'replace', check = False, startupinfo = startupinfo)

                popup_progreso.destroy()  # Cerrar popup de progreso

                if proceso.returncode == 0:
                    messagebox.showinfo("Descarga Completada",
                                        "El comando de descarga parece haberse completado con éxito.\nSe intentará inicializar el sistema NLP nuevamente.",
                                        parent = root)
                    descarga_o_intento_valido = True
                else:
                    error_detalle = f"Salida:\n{proceso.stdout}\nError:\n{proceso.stderr}"
                    messagebox.showerror("Error de Descarga",
                                         f"El comando de descarga falló (código: {proceso.returncode}).\n{error_detalle}",
                                         parent = root)
                    descarga_o_intento_valido = False
            except FileNotFoundError:  # Si `python` o `spacy` no está en el PATH dentro del subprocess
                popup_progreso.destroy()
                messagebox.showerror("Error de Comando",
                                     f"No se pudo encontrar el ejecutable para: {' '.join(comando_descarga_lista)}\nAsegúrese de que Python y spaCy estén en el PATH del sistema.",
                                     parent = root)
                descarga_o_intento_valido = False
            except Exception as e_sub:
                popup_progreso.destroy()
                messagebox.showerror("Error Inesperado",
                                     f"Ocurrió un error al ejecutar el comando de descarga:\n{e_sub}", parent = root)
                descarga_o_intento_valido = False

        elif tipo_modelo == 'sentencetransformers':  # No hay comando, solo reintentar inicialización
            descarga_o_intento_valido = True  # Proceder directamente al reintento de inicialización

        if descarga_o_intento_valido:
            mostrar_popup_cargando(root, "Reintentando inicialización del sistema NLP...")
            estado_reintento, mensaje_reintento = ai_nlp.inicializar_sistema_npl()
            nlp_sistema_listo = estado_reintento  # Actualizar el estado global
            cerrar_popup_cargando()

            if estado_reintento:
                messagebox.showinfo("Inicialización Exitosa",
                                    f"{mensaje_reintento}\n\nEl sistema NLP está listo.\nPor favor, intente la acción 'Extraer Parámetros' nuevamente.",
                                    parent = root)
            else:
                messagebox.showerror("Fallo en Reintento",
                                     f"La inicialización del sistema NLP falló nuevamente:\n{mensaje_reintento}",
                                     parent = root)
        # Si descarga_o_intento_valido es False, nlp_sistema_listo no se actualiza o permanece False.

    def cancelar_accion():
        intento_realizado.set(False)  # No se intentó la acción principal
        popup.destroy()

    button_frame = ttk.Frame(popup, padding = (0, 10, 0, 10))
    button_frame.pack(fill = "x")

    btn_accion_texto = "Descargar Modelo y Reintentar" if tipo_modelo == 'spacy' else "Reintentar Inicialización"
    btn_accion = ttk.Button(button_frame, text = btn_accion_texto, command = ejecutar_accion_y_reintentar,
                            style = "Accent.TButton")
    btn_accion.pack(side = tk.RIGHT, padx = 5)

    btn_cancelar = ttk.Button(button_frame, text = "Cancelar", command = cancelar_accion)
    btn_cancelar.pack(side = tk.RIGHT, padx = 5)  # Ponerlo a la izquierda del botón de acción

    # Esperar a que el popup se cierre para continuar el flujo en accion_principal_paso
    root.wait_window(popup)
    return nlp_sistema_listo

# --- Flujo Paso 1 y Word (sin cambios) ---
def ejecutar_flujo_completo_paso1(ruta_imagen_seleccionada, section_data_paso1):
    if not ruta_imagen_seleccionada:
        messagebox.showerror("Error P1", "No se ha seleccionado imagen.")
        return False
    img_proc = image_preprocessor.preprocesar_imagen(ruta_imagen_seleccionada)
    if img_proc is None:
        messagebox.showerror("Error P1", "Fallo preprocesamiento.")
        return False
    texto_transcrito_ocr_original = "" 
    texto_para_nlp = ""                
    try:
        extracted_data = text_extractor.extraer_texto(img_proc)
        if isinstance(extracted_data, tuple) and extracted_data[0] is False:
            messagebox.showerror(str(extracted_data[1]), str(extracted_data[2]))
            return False
        elif isinstance(extracted_data, str):
            texto_transcrito_ocr_original = extracted_data
            texto_para_nlp = texto_transcrito_ocr_original 
        else:
            messagebox.showerror("Error OCR", f"Respuesta inesperada del extractor de texto: {type(extracted_data)}")
            return False
        section_data_paso1['texto_ocr_original_para_word1'] = texto_transcrito_ocr_original
        if not texto_para_nlp.strip(): 
            messagebox.showwarning("Advertencia OCR", "El OCR no extrajo texto o el texto está vacío.")
            section_data_paso1['texto_ocr_obtenido'] = "" 
        else:
            indice_corte_final = len(texto_para_nlp)
            patron_determine = r"\b(?:Determine|Determinar|Determina|Determinese)\b"
            match_determine = re.search(patron_determine, texto_para_nlp, re.IGNORECASE)
            if match_determine:
                indice_corte_final = min(indice_corte_final, match_determine.start())
            patron_preguntas_corte = r"^\s*(?:\([a-zA-Z\d]+\)\s*|\b[a-zA-Z\d]+\.\s*)?¿(?=.*[a-zA-ZÀ-ÖØ-öø-ÿ])"
            match_pregunta = re.search(patron_preguntas_corte, texto_para_nlp, re.MULTILINE | re.IGNORECASE)
            if match_pregunta:
                indice_corte_final = min(indice_corte_final, match_pregunta.start())
            if indice_corte_final < len(texto_para_nlp):
                texto_limpio_para_nlp = texto_para_nlp[:indice_corte_final].strip()
            else:
                texto_limpio_para_nlp = texto_para_nlp.strip() 
            section_data_paso1['texto_ocr_obtenido'] = texto_limpio_para_nlp
    except pytesseract.TesseractNotFoundError:
        messagebox.showerror("Error Tesseract", "Tesseract no encontrado. Verifique la instalación y configuración.")
        section_data_paso1['texto_ocr_original_para_word1'] = texto_transcrito_ocr_original 
        section_data_paso1['texto_ocr_obtenido'] = texto_transcrito_ocr_original 
        return False
    except pytesseract.TesseractError as e:
        messagebox.showerror("Error Tesseract", f"Error durante OCR: {e}")
        section_data_paso1['texto_ocr_original_para_word1'] = texto_transcrito_ocr_original
        section_data_paso1['texto_ocr_obtenido'] = texto_transcrito_ocr_original
        return False
    except Exception as e:
        messagebox.showerror("Error OCR", f"Error inesperado en extracción de texto: {e}")
        section_data_paso1['texto_ocr_original_para_word1'] = texto_transcrito_ocr_original
        section_data_paso1['texto_ocr_obtenido'] = texto_transcrito_ocr_original
        return False
    nombre_doc_original = "WORD #1.docx"
    texto_a_guardar_en_word1 = section_data_paso1.get('texto_ocr_original_para_word1', texto_transcrito_ocr_original)
    if document_generator.guardar_en_word(texto_a_guardar_en_word1, nombre_doc_original, PROJECT_ROOT_DIR):
        return True
    else:
        messagebox.showerror("Error P1", f"No se pudo guardar el documento original '{nombre_doc_original}'.")
        return False
def leer_texto_desde_word(ruta_word):
    try:
        if not os.path.exists(ruta_word): return None, f"No encontrado: {os.path.basename(ruta_word)}"
        doc=Document(ruta_word); titulo_word=None; parrafos_texto=[]
        for para in doc.paragraphs:
            if titulo_word is None and para.style.name == 'Heading 1' and para.text.strip(): titulo_word = para.text.strip()
            elif para.text.strip() and not (titulo_word and titulo_word == para.text.strip()): parrafos_texto.append(para.text.strip())
        if titulo_word is None and parrafos_texto: titulo_word = parrafos_texto.pop(0)
        elif titulo_word is None and not parrafos_texto: return "Documento Vacío","Contenido vacío."
        return titulo_word, "\n\n".join(parrafos_texto)
    except Exception as e: print(f"Error al leer Word '{ruta_word}':{e}"); return None,f"Err leer:{os.path.basename(ruta_word)}({e})"
def cargar_y_mostrar_word_paso2(s_data):
    lbl_tit=s_data.get('word_title_label'); txt_w_w=s_data.get('word_text_widget')
    if not lbl_tit or not txt_w_w: return
    nom_doc="WORD #1.docx"; r_c_w=os.path.join(PROJECT_ROOT_DIR,"docs",nom_doc)
    tit_l, cuer_l=leer_texto_desde_word(r_c_w)
    lbl_tit.config(text=tit_l if tit_l else "No se cargó título.")
    txt_w_w.config(state='normal'); txt_w_w.delete('1.0',tk.END)
    txt_w_w.insert(tk.END,cuer_l if cuer_l else "No se cargó contenido."); txt_w_w.config(state='disabled')

def inicializar_estructura_parametros_ai():
    return {"tasa_llegada":{"valor":None,"unidades":None,"distribucion":None,"fragmento_texto":None},"tiempo_entre_llegadas":{"valor":None,"unidades":None,"distribucion":None,"fragmento_texto":None},"tasa_servicio_por_servidor":{"valor":None,"unidades":None,"distribucion":None,"fragmento_texto":None},"tiempo_servicio_por_servidor":{"valor":None,"unidades":None,"distribucion":None,"fragmento_texto":None},"cantidad_servidores":{"valor":None,"fragmento_texto":None},"capacidad_sistema":{"valor":None,"fragmento_texto":None},"disciplina_cola":{"valor":None,"fragmento_texto":None}}

def poblar_campos_paso3_desde_ai(section_data_paso3):
    widgets_map = section_data_paso3.get('widgets_map_paso3', {})
    if not widgets_map: return

    action_button = section_data_paso3.get('action_button_principal')
    paso_completado = action_button and action_button.cget('state') == 'disabled'
    
    source_params = None
    if paso_completado and section_data_paso3.get('parametros_consolidados_finales'):
        source_params = section_data_paso3.get('parametros_consolidados_finales')
    else:
        ai_params_base = section_data_paso3.get('ai_parametros_prellenados', {})
        source_params = ai_params_base.get("parametros_extraidos", inicializar_estructura_parametros_ai())
    
    if not source_params: # Fallback por si acaso
        source_params = inicializar_estructura_parametros_ai()


    def _set_entry_value(entry_widget, value, placeholder_text, is_disabled_step):
        original_state = entry_widget.cget('state')
        entry_widget.config(state='normal') # Habilitar para modificar
        
        entry_widget.delete(0, tk.END)
        if value is not None and str(value).strip() != "":
            entry_widget.insert(0, str(value))
            if hasattr(entry_widget, 'placeholder_info'):
                entry_widget.config(foreground=entry_widget.placeholder_info['original_fg'])
            else:
                entry_widget.config(foreground='black')
        else:
            if hasattr(entry_widget, 'placeholder_info'):
                 original_fg = entry_widget.placeholder_info['original_fg']
                 text_placeholder = entry_widget.placeholder_info['text']
                 entry_widget.insert(0, text_placeholder)
                 entry_widget.config(foreground=COLOR_GRIS_TEXTO_PLACEHOLDER)
                 entry_widget.unbind("<FocusIn>") # Limpiar bindings para evitar duplicados
                 entry_widget.unbind("<FocusOut>")
                 entry_widget.bind("<FocusIn>", lambda event, c_entry=entry_widget, txt=text_placeholder, o_fg=original_fg: (
                    c_entry.delete(0, tk.END), c_entry.config(foreground=o_fg)) if c_entry.get() == txt and str(c_entry.cget('foreground')) == COLOR_GRIS_TEXTO_PLACEHOLDER else None, add='+')
                 entry_widget.bind("<FocusOut>", lambda event, c_entry=entry_widget, txt=text_placeholder: (
                    c_entry.delete(0, tk.END), c_entry.insert(0, txt), c_entry.config(foreground=COLOR_GRIS_TEXTO_PLACEHOLDER)) if not c_entry.get().strip() else None, add='+')
            else: 
                 entry_widget.insert(0, placeholder_text)
                 entry_widget.config(foreground=COLOR_GRIS_TEXTO_PLACEHOLDER)
        
        if is_disabled_step: # Si el paso general está deshabilitado, deshabilitar entry
            entry_widget.config(state='disabled')
        elif original_state == 'disabled' and not is_disabled_step: # Si estaba deshabilitado pero el paso no lo está (ej. reinicio)
             pass # Dejarlo normal (ya lo está)
        elif original_state == 'disabled' and is_disabled_step: # Doble check
             entry_widget.config(state='disabled')


    def _set_combo_value(combobox_widget, unit_value, unit_options_list, default_selection_if_no_unit, is_disabled_step):
        original_state = combobox_widget.cget('state')
        combobox_widget.config(state='readonly') # Habilitar para modificar
        
        unit_str = str(unit_value).strip() if unit_value is not None else None
        
        current_combo_values = list(combobox_widget.cget("values"))
        if list(unit_options_list) != current_combo_values: 
            combobox_widget.config(values=list(unit_options_list))

        target_unit_to_set = None
        if unit_str:
            if unit_str in unit_options_list:
                target_unit_to_set = unit_str
            else: 
                new_values_for_combo = list(unit_options_list) 
                if unit_str not in new_values_for_combo:
                    new_values_for_combo.insert(0, unit_str)
                combobox_widget.config(values=new_values_for_combo)
                target_unit_to_set = unit_str
        
        if target_unit_to_set:
            combobox_widget.set(target_unit_to_set)
        else:
            combobox_widget.set(default_selection_if_no_unit)

        if is_disabled_step: # Si el paso general está deshabilitado, deshabilitar combobox
            combobox_widget.config(state='disabled')
        elif original_state == 'disabled' and not is_disabled_step:
            pass # Dejarlo readonly (ya lo está)
        elif original_state == 'disabled' and is_disabled_step:
            combobox_widget.config(state='disabled')


    # --- Lógica para Llegadas ---
    llegada_tasa_data = source_params.get("tasa_llegada", {})
    llegada_tiempo_data = source_params.get("tiempo_entre_llegadas", {})
    
    entry_llegadas = widgets_map['entry_llegadas_valor']
    combo_llegadas_unidad = widgets_map['combo_llegadas_unidad']
    label_llegadas = widgets_map['label_llegadas']

    if llegada_tasa_data.get("valor") is not None:
        label_llegadas.config(text="Tasa de llegadas (λ):")
        _set_entry_value(entry_llegadas, llegada_tasa_data.get("valor"), PLACEHOLDER_EJ_20, paso_completado)
        _set_combo_value(combo_llegadas_unidad, llegada_tasa_data.get("unidades"), DEFAULT_RATE_UNITS, DEFAULT_LAMBDA_UNIT_SELECTION, paso_completado)
        section_data_paso3['arrival_is_rate'] = True # Actualizar estado para construir_json
    elif llegada_tiempo_data.get("valor") is not None:
        label_llegadas.config(text="Tiempo entre llegadas (1/λ):")
        _set_entry_value(entry_llegadas, llegada_tiempo_data.get("valor"), PLACEHOLDER_INGRESE_VALOR, paso_completado)
        _set_combo_value(combo_llegadas_unidad, llegada_tiempo_data.get("unidades"), DEFAULT_TIME_UNITS, DEFAULT_TIME_UNITS[0] if DEFAULT_TIME_UNITS else "", paso_completado)
        section_data_paso3['arrival_is_rate'] = False
    else: 
        label_llegadas.config(text="Tasa de llegadas (λ):")
        _set_entry_value(entry_llegadas, None, PLACEHOLDER_EJ_20, paso_completado) 
        _set_combo_value(combo_llegadas_unidad, None, DEFAULT_RATE_UNITS, DEFAULT_LAMBDA_UNIT_SELECTION, paso_completado)
        section_data_paso3['arrival_is_rate'] = True

    # --- Lógica para Servicios ---
    servicio_tasa_data = source_params.get("tasa_servicio_por_servidor", {})
    servicio_tiempo_data = source_params.get("tiempo_servicio_por_servidor", {})

    entry_servicios = widgets_map['entry_servicios_valor']
    combo_servicios_unidad = widgets_map['combo_servicios_unidad']
    label_servicios = widgets_map['label_servicios']

    # Priorizar tiempo si viene de la fuente (especialmente si es `parametros_consolidados_finales`)
    if servicio_tiempo_data.get("valor") is not None: 
        label_servicios.config(text="Tiempo de servicio (1/μ):")
        _set_entry_value(entry_servicios, servicio_tiempo_data.get("valor"), PLACEHOLDER_INGRESE_VALOR, paso_completado)
        _set_combo_value(combo_servicios_unidad, servicio_tiempo_data.get("unidades"), DEFAULT_TIME_UNITS, DEFAULT_MU_TIME_UNIT_SELECTION, paso_completado)
        section_data_paso3['service_is_time'] = True
    elif servicio_tasa_data.get("valor") is not None:
        label_servicios.config(text="Tasa de servicio (μ):")
        _set_entry_value(entry_servicios, servicio_tasa_data.get("valor"), PLACEHOLDER_INGRESE_VALOR, paso_completado)
        _set_combo_value(combo_servicios_unidad, servicio_tasa_data.get("unidades"), DEFAULT_RATE_UNITS, DEFAULT_RATE_UNITS[0] if DEFAULT_RATE_UNITS else "", paso_completado)
        section_data_paso3['service_is_time'] = False
    else: 
        label_servicios.config(text="Tiempo de servicio (1/μ):")
        _set_entry_value(entry_servicios, None, PLACEHOLDER_INGRESE_VALOR, paso_completado) 
        _set_combo_value(combo_servicios_unidad, None, DEFAULT_TIME_UNITS, DEFAULT_MU_TIME_UNIT_SELECTION, paso_completado)
        section_data_paso3['service_is_time'] = True
        
    # S y K
    cap_sis_data = source_params.get("capacidad_sistema", {})
    if 'entry_k' in widgets_map: _set_entry_value(widgets_map['entry_k'], cap_sis_data.get("valor"), PLACEHOLDER_INGRESE_VALOR, paso_completado)
    
    cant_serv_data = source_params.get("cantidad_servidores", {})
    if 'entry_s' in widgets_map: _set_entry_value(widgets_map['entry_s'], cant_serv_data.get("valor"), PLACEHOLDER_INGRESE_VALOR, paso_completado)

def abrir_popup_medidas_desempeno(parametros_finales_paso3):
    DISPLAY_CONFIG_MEDIDAS = [
    {
        "label_ui": "λ",
        "potential_keys": ["lambda_original_oferta", "lambda_normalizada_por_hora", "lambda_normalizada_hora"], # M/M/1K usa la primera, M/M/1 la segunda, M/M/s la tercera
        "unit": "clientes/hora", "format_spec": "{:.4f}", "k_dependent": False
    },
    {
        "label_ui": "μ", # Mostrando Tiempo de servicio promedio
        "potential_keys": ["Ts_servicio_promedio_horas"], # Todas las funciones parecen usar esta (con T mayúscula)
        "unit": "clientes/hora", "format_spec": "{:.4f}", "k_dependent": False
    },
    {
        "label_ui": "ρ",
        "potential_keys": ["rho_factor_utilizacion_ofrecido", "rho_utilizacion", "rho_s_utilizacion_por_servidor"], # M/M/1K, M/M/1, M/M/s y M/M/s/K (que usa rho_s_trafico_por_servidor, pero rho_s_utilizacion_por_servidor es más general para M/M/s)
        "unit": "", "format_spec": "{:.4f}", "k_dependent": False
    },
    {
        "label_ui": "K",
        "potential_keys": ["K_capacidad_sistema"], # M/M/1K y M/M/s/K usan esta (con K mayúscula)
        "unit": "clientes", "format_spec": "{}", "k_dependent": True
    },
    {
        "label_ui": "P0",
        "potential_keys": ["P0_sistema_vacio"], # Todas las funciones parecen usar esta (con P mayúscula)
        "unit": "", "format_spec": "{:.5f}", "k_dependent": False
    },
    {
        "label_ui": "λefect",
        "potential_keys": ["lambda_efectiva_entradas"], # M/M/1K y M/M/s/K usan esta
        "unit": "clientes/hora", "format_spec": "{:.4f}", "k_dependent": True
    },
    {
        "label_ui": "L",
        "potential_keys": ["L_sistema_promedio"], # Todas las funciones parecen usar esta (con L mayúscula)
        "unit": "clientes", "format_spec": "{:.4f}", "k_dependent": False
    },
    {
        "label_ui": "Lq",
        "potential_keys": ["Lq_cola_promedio"], # Todas las funciones parecen usar esta (con Lq mayúsculas)
        "unit": "clientes", "format_spec": "{:.4f}", "k_dependent": False
    },
    {
        "label_ui": "W",
        "potential_keys": ["W_sistema_promedio_horas"], # Todas las funciones parecen usar esta (con W mayúscula)
        "unit": "horas", "format_spec": "{:.4f}", "k_dependent": False
    },
    {
        "label_ui": "Wq",
        "potential_keys": ["Wq_cola_promedio_horas"], # Todas las funciones parecen usar esta (con Wq mayúsculas)
        "unit": "horas", "format_spec": "{:.4f}", "k_dependent": False
    },
]
    if not parametros_finales_paso3:
        messagebox.showerror("Error", "No hay parámetros consolidados del Paso 3 para calcular las medidas.")
        return

    try:
        exito_id, modelo_str_completo = calculator.identificar_modelo_cola(parametros_finales_paso3)
    except AttributeError:
        messagebox.showerror("Error de Módulo", "La función 'identificar_modelo_cola' no se encontró en el módulo 'calculator'.")
        return
    except Exception as e_ident:
        messagebox.showerror("Error de Identificación", f"Error al identificar el modelo: {e_ident}")
        return

    popup_medidas = tk.Toplevel(root)
    popup_medidas.title("Medidas de Desempeño") # Título genérico de la ventana
    popup_medidas.geometry("450x400") # Ajusta el tamaño
    popup_medidas.transient(root)
    popup_medidas.grab_set()
    root.update_idletasks()
    x_coord = int((popup_medidas.winfo_screenwidth() / 2) - (popup_medidas.winfo_width() / 2))
    y_coord = int((popup_medidas.winfo_screenheight() / 2) - (popup_medidas.winfo_height() / 2))
    popup_medidas.geometry(f"+{x_coord}+{y_coord}")

    text_frame = ttk.Frame(popup_medidas, padding=10)
    text_frame.pack(expand=True, fill=tk.BOTH)

    text_area_resultados = tk.Text(text_frame, wrap=tk.WORD, font=FONT_NORMAL, padx=5, pady=5, relief="solid", borderwidth=1,spacing1=2, spacing3=2) # spacing para interlineado
    scrollbar_resultados = ttk.Scrollbar(text_frame, orient=tk.VERTICAL, command=text_area_resultados.yview)
    text_area_resultados.config(yscrollcommand=scrollbar_resultados.set)
    scrollbar_resultados.pack(side=tk.RIGHT, fill=tk.Y)
    text_area_resultados.pack(side=tk.LEFT, expand=True, fill=tk.BOTH)

    # Configurar tag para centrar el título
    text_area_resultados.tag_configure("centered_title", justify="center", font=FONT_BOLD)
    text_area_resultados.tag_configure("error", foreground="red", font=FONT_NORMAL)
    text_area_resultados.tag_configure("data_label", font=FONT_BOLD)
    text_area_resultados.tag_configure("data_value", font=FONT_NORMAL)

    resultados_calculados = None
    calculo_exitoso = False
    
    # Insertar título centrado
    text_area_resultados.insert(tk.END, f"{modelo_str_completo if exito_id else 'Error de Identificación'}\n", "centered_title")
    text_area_resultados.insert(tk.END, ("-" * 50) + "\n\n", "centered_title")


    if not exito_id:
        text_area_resultados.insert(tk.END, f"No se pudo determinar el modelo de colas.\nDetalle: {modelo_str_completo}\n\nNo se pueden calcular las medidas.", "error")
    else:
        # Determinar el nombre canónico del modelo para la lógica de cálculo
        # Esto es para mantener la lógica de despacho a las funciones de cálculo.
        # El `modelo_str_completo` se usa para el título.
        canonical_model_name = ""
        if modelo_str_completo.startswith("M/M/s/K"): canonical_model_name = "M/M/s/K"
        elif modelo_str_completo.startswith("M/M/1/K"): canonical_model_name = "M/M/1/K"
        elif modelo_str_completo.startswith("M/M/s"): canonical_model_name = "M/M/s"
        elif modelo_str_completo.startswith("M/M/1"): canonical_model_name = "M/M/1"

        try:
            if canonical_model_name == "M/M/1":
                resultados_calculados = calculator.calcular_medidas_mm1(parametros_finales_paso3)
            elif canonical_model_name == "M/M/1/K":
                resultados_calculados = calculator.calcular_medidas_mm1k(parametros_finales_paso3)
            elif canonical_model_name == "M/M/s":
                resultados_calculados = calculator.calcular_medidas_mms(parametros_finales_paso3)
            elif canonical_model_name == "M/M/s/K":
                resultados_calculados = calculator.calcular_medidas_mmsk(parametros_finales_paso3)
            else:
                resultados_calculados = f"El modelo '{modelo_str_completo}' no tiene una función de cálculo de medidas asociada."
            
            calculo_exitoso = isinstance(resultados_calculados, dict)

        except AttributeError as e_attr:
             resultados_calculados = f"Error de Módulo: Función de cálculo para '{canonical_model_name}' no encontrada o mal definida en 'calculator'.\n{e_attr}"
        except Exception as e_calc:
            resultados_calculados = f"Error durante el cálculo de medidas para '{canonical_model_name}':\n{e_calc}"

        if isinstance(resultados_calculados, str): # Error o mensaje informativo
            text_area_resultados.insert(tk.END, resultados_calculados, "error")
        elif isinstance(resultados_calculados, dict):
            is_k_model = "/K" in modelo_str_completo # Chequea si el modelo original identificado tiene K

            for item_config in DISPLAY_CONFIG_MEDIDAS:
                if item_config["k_dependent"] and not is_k_model:
                    continue # Saltar parámetros dependientes de K si no es un modelo K

                valor_encontrado = None
                clave_usada = ""
                for potential_key in item_config["potential_keys"]:
                    if potential_key in resultados_calculados:
                        valor_encontrado = resultados_calculados[potential_key]
                        clave_usada = potential_key
                        break
                
                if valor_encontrado is not None:
                    try:
                        # Formatear el valor numérico
                        if isinstance(valor_encontrado, (int, float)):
                            formatted_value = item_config["format_spec"].format(valor_encontrado)
                        else: # Si no es numérico (ej. un string de error dentro del dict), mostrar tal cual
                            formatted_value = str(valor_encontrado)
                    except (ValueError, TypeError):
                        formatted_value = str(valor_encontrado) # Fallback si el formato falla

                    text_area_resultados.insert(tk.END, f"{item_config['label_ui']} = ", "data_label")
                    text_area_resultados.insert(tk.END, f"{formatted_value} {item_config['unit']}\n", "data_value")

        else: # Tipo de resultado inesperado
            text_area_resultados.insert(tk.END, "Error: Tipo de resultado inesperado del cálculo de medidas.", "error")

    text_area_resultados.config(state="disabled")

    button_frame = ttk.Frame(popup_medidas, style="TopButtons.TFrame") # Reusar estilo si quieres fondo igual
    button_frame.pack(pady=(5,10))
    ttk.Button(button_frame, text="Cerrar", command=popup_medidas.destroy, style="Accent.TButton").pack()

    popup_medidas.wait_window()

def construir_json_final_paso3(section_data_paso3):
    # (Sin cambios significativos aquí, la lógica de manejo de "infinita" ya estaba correcta)
    widgets_map = section_data_paso3.get('widgets_map_paso3', {})
    ai_original_params_full = section_data_paso3.get('ai_parametros_prellenados', {})
    ai_original_params_extracted = ai_original_params_full.get("parametros_extraidos", inicializar_estructura_parametros_ai())
    final_params = inicializar_estructura_parametros_ai()

    for key_param, details_param_ai in ai_original_params_extracted.items():
        if key_param not in ["tasa_llegada", "tiempo_entre_llegadas", "tasa_servicio_por_servidor", "tiempo_servicio_por_servidor", "cantidad_servidores", "capacidad_sistema"]:
            if key_param in final_params and isinstance(details_param_ai, dict):
                for sub_key, sub_val in details_param_ai.items():
                    if sub_key in final_params[key_param]:
                        final_params[key_param][sub_key] = sub_val
        if key_param == "disciplina_cola" and details_param_ai.get("valor"):
             final_params["disciplina_cola"] = details_param_ai.copy()

    def get_gui_numeric_value(widget_name, placeholder, is_int=False):
        widget = widgets_map.get(widget_name)
        if not widget: return None
        val_str = widget.get()
        ph_info = getattr(widget, 'placeholder_info', None)
        if ph_info and ph_info.get('text') == val_str and str(widget.cget('foreground')) == COLOR_GRIS_TEXTO_PLACEHOLDER:
             return None 
        if not val_str.strip(): return None
        try: 
            num = float(val_str.replace(",", "."))
            return int(num) if is_int else num
        except ValueError: return None

    arrival_is_rate = section_data_paso3.get('arrival_is_rate', True) 
    gui_arrival_val = get_gui_numeric_value('entry_llegadas_valor', PLACEHOLDER_EJ_20 if arrival_is_rate else PLACEHOLDER_INGRESE_VALOR)
    gui_arrival_unit = widgets_map.get('combo_llegadas_unidad', {}).get()

    if arrival_is_rate:
        ai_data = ai_original_params_extracted.get("tasa_llegada", {})
        ai_original_val = ai_data.get("valor")
        ai_original_dist = ai_data.get("distribucion")
        ai_original_frag = ai_data.get("fragmento_texto")

        if gui_arrival_val is not None:
            final_params["tasa_llegada"]["valor"] = gui_arrival_val
            final_params["tasa_llegada"]["unidades"] = gui_arrival_unit
            modificado = False
            if ai_original_val is None: modificado = True
            else:
                try:
                    if float(gui_arrival_val) != float(ai_original_val) : modificado = True
                except ValueError: modificado = True 
            
            if modificado or not ai_original_frag:
                final_params["tasa_llegada"]["fragmento_texto"] = "Ingresado o modificado por el usuario"
                final_params["tasa_llegada"]["distribucion"] = "Poisson" 
            else: 
                final_params["tasa_llegada"]["distribucion"] = ai_original_dist
                final_params["tasa_llegada"]["fragmento_texto"] = ai_original_frag
            
            # Asegurar que la distribución para tasa_llegada no quede None si hay valor
            if final_params["tasa_llegada"]["valor"] is not None and \
               final_params["tasa_llegada"]["distribucion"] is None:
                final_params["tasa_llegada"]["distribucion"] = "Poisson"

        # Limpiar el parámetro alternativo (tiempo_entre_llegadas)
        final_params["tiempo_entre_llegadas"] = inicializar_estructura_parametros_ai()["tiempo_entre_llegadas"]

    else: # Arrival is Time (arrival_is_rate is False)
        ai_data = ai_original_params_extracted.get("tiempo_entre_llegadas", {})
        ai_original_val = ai_data.get("valor")
        ai_original_dist = ai_data.get("distribucion")
        ai_original_frag = ai_data.get("fragmento_texto")

        if gui_arrival_val is not None:
            final_params["tiempo_entre_llegadas"]["valor"] = gui_arrival_val
            final_params["tiempo_entre_llegadas"]["unidades"] = gui_arrival_unit
            modificado = False
            if ai_original_val is None: modificado = True
            else:
                try:
                    if float(gui_arrival_val) != float(ai_original_val) : modificado = True
                except ValueError: modificado = True
            
            if modificado or not ai_original_frag:
                final_params["tiempo_entre_llegadas"]["fragmento_texto"] = "Ingresado o modificado por el usuario"
                final_params["tiempo_entre_llegadas"]["distribucion"] = "Exponencial"
            else: # Mantener distribución y fragmento de AI si el valor no cambió
                final_params["tiempo_entre_llegadas"]["distribucion"] = ai_original_dist 
                final_params["tiempo_entre_llegadas"]["fragmento_texto"] = ai_original_frag
            
            # >>> ESTA ES LA LÍNEA QUE DEBE ESTAR AQUÍ <<<
            if final_params["tiempo_entre_llegadas"]["valor"] is not None and \
               final_params["tiempo_entre_llegadas"]["distribucion"] is None:
                final_params["tiempo_entre_llegadas"]["distribucion"] = "Exponencial"
        
        # Limpiar el parámetro alternativo (tasa_llegada)
        final_params["tasa_llegada"] = inicializar_estructura_parametros_ai()["tasa_llegada"]


    service_is_time = section_data_paso3.get('service_is_time', True) 
    gui_service_val = get_gui_numeric_value('entry_servicios_valor', PLACEHOLDER_INGRESE_VALOR)
    gui_service_unit = widgets_map.get('combo_servicios_unidad', {}).get()

    if service_is_time:
        ai_data = ai_original_params_extracted.get("tiempo_servicio_por_servidor", {})
        # ... (resto de la lógica para servicios-tiempo, sin cambios)
        ai_original_val = ai_data.get("valor"); ai_original_dist = ai_data.get("distribucion"); ai_original_frag = ai_data.get("fragmento_texto")
        if gui_service_val is not None:
            final_params["tiempo_servicio_por_servidor"]["valor"] = gui_service_val; final_params["tiempo_servicio_por_servidor"]["unidades"] = gui_service_unit
            modificado = False
            if ai_original_val is None: modificado = True
            else:
                try: 
                    if float(gui_service_val) != float(ai_original_val) : modificado = True
                except ValueError: modificado = True
            if modificado or not ai_original_frag:
                final_params["tiempo_servicio_por_servidor"]["fragmento_texto"] = "Ingresado o modificado por el usuario"; final_params["tiempo_servicio_por_servidor"]["distribucion"] = "Exponencial"
            else:
                final_params["tiempo_servicio_por_servidor"]["distribucion"] = ai_original_dist; final_params["tiempo_servicio_por_servidor"]["fragmento_texto"] = ai_original_frag
        final_params["tasa_servicio_por_servidor"] = inicializar_estructura_parametros_ai()["tasa_servicio_por_servidor"]
    else: 
        ai_data = ai_original_params_extracted.get("tasa_servicio_por_servidor", {})
        # ... (resto de la lógica para servicios-tasa, sin cambios)
        ai_original_val = ai_data.get("valor"); ai_original_dist = ai_data.get("distribucion"); ai_original_frag = ai_data.get("fragmento_texto")
        if gui_service_val is not None:
            final_params["tasa_servicio_por_servidor"]["valor"] = gui_service_val; final_params["tasa_servicio_por_servidor"]["unidades"] = gui_service_unit
            modificado = False
            if ai_original_val is None: modificado = True
            else:
                try:
                    if float(gui_service_val) != float(ai_original_val) : modificado = True
                except ValueError: modificado = True
            if modificado or not ai_original_frag:
                final_params["tasa_servicio_por_servidor"]["fragmento_texto"] = "Ingresado o modificado por el usuario"; final_params["tasa_servicio_por_servidor"]["distribucion"] = "Poisson"
            else:
                final_params["tasa_servicio_por_servidor"]["distribucion"] = ai_original_dist; final_params["tasa_servicio_por_servidor"]["fragmento_texto"] = ai_original_frag
        final_params["tiempo_servicio_por_servidor"] = inicializar_estructura_parametros_ai()["tiempo_servicio_por_servidor"]
        
    gui_k_val = get_gui_numeric_value('entry_k', PLACEHOLDER_INGRESE_VALOR, is_int=True)
    ai_k_data_original = ai_original_params_extracted.get("capacidad_sistema", {})
    ai_k_valor_original = ai_k_data_original.get("valor")
    ai_k_fragmento_original = ai_k_data_original.get("fragmento_texto")
    if gui_k_val is not None: 
        final_params["capacidad_sistema"]["valor"] = gui_k_val
        modificado_k = False
        if ai_k_valor_original is None: modificado_k = True
        else:
            if isinstance(ai_k_valor_original, (int, float)): 
                if gui_k_val != int(ai_k_valor_original): modificado_k = True
            else: modificado_k = True 
        if modificado_k or not ai_k_fragmento_original:
            final_params["capacidad_sistema"]["fragmento_texto"] = "Ingresado o modificado por el usuario"
        else: final_params["capacidad_sistema"]["fragmento_texto"] = ai_k_fragmento_original
    elif ai_k_valor_original is not None: 
        final_params["capacidad_sistema"]["valor"] = ai_k_valor_original
        final_params["capacidad_sistema"]["fragmento_texto"] = ai_k_fragmento_original
    else: final_params["capacidad_sistema"]["valor"] = None

    gui_s_val = get_gui_numeric_value('entry_s', PLACEHOLDER_INGRESE_VALOR, is_int=True)
    ai_s_data_original = ai_original_params_extracted.get("cantidad_servidores", {})
    ai_s_valor_original = ai_s_data_original.get("valor")
    ai_s_fragmento_original = ai_s_data_original.get("fragmento_texto")
    if gui_s_val is not None: 
        final_params["cantidad_servidores"]["valor"] = gui_s_val
        modificado_s = False
        if ai_s_valor_original is None: modificado_s = True
        else:
            if isinstance(ai_s_valor_original, (int, float)):
                if gui_s_val != int(ai_s_valor_original): modificado_s = True
            else: modificado_s = True
        if modificado_s or not ai_s_fragmento_original:
            final_params["cantidad_servidores"]["fragmento_texto"] = "Ingresado o modificado por el usuario"
        else: final_params["cantidad_servidores"]["fragmento_texto"] = ai_s_fragmento_original
    elif ai_s_valor_original is not None: 
        final_params["cantidad_servidores"]["valor"] = ai_s_valor_original
        final_params["cantidad_servidores"]["fragmento_texto"] = ai_s_fragmento_original
    else: final_params["cantidad_servidores"]["valor"] = None

    section_data_paso3['parametros_consolidados_finales'] = final_params
    print("\n--- Parámetros Consolidados Finales (Paso 3) ---"); print(json.dumps(final_params, indent=4, ensure_ascii=False)); print("----------------------------------------------\n")
    return final_params

# --- Funciones para Verificar Supuestos (sin cambios respecto a la última versión) ---
def verificar_supuesto_1_gui(params):
    t_lleg = params.get("tasa_llegada", {}) 
    t_e_lleg = params.get("tiempo_entre_llegadas", {})
    val_l = t_lleg.get("valor"); val_tel = t_e_lleg.get("valor")
    dist_tasa = str(t_lleg.get("distribucion", "")).lower(); dist_tiempo = str(t_e_lleg.get("distribucion", "")).lower()
    capacidad = params.get("capacidad_sistema", {}); capacidad_valor = capacidad.get("valor")
    detalle = ""; ok = False
    condicion_llegada_valida = (val_l is not None and "poisson" in dist_tasa) or (val_tel is not None and "exponencial" in dist_tiempo)
    if condicion_llegada_valida:
        param_usado = "λ_n" if val_l is not None else "λ_n"; dist_desc = "exponencial" 
        if capacidad_valor is not None and isinstance(capacidad_valor, (int, float)) and capacidad_valor > 0 :
            detalle = f"Dado N(t) = n, la distribución de probabilidad actual del tiempo que falta para el próximo nacimiento (llegada) es {dist_desc} con parámetro {param_usado} (n = 0, 1, ..., {int(capacidad_valor)-1})."
        else: detalle = f"Dado N(t) = n, la distribución de probabilidad actual del tiempo que falta para el próximo nacimiento (llegada) es {dist_desc} con parámetro {param_usado} (n = 0, 1, ...)."
        ok = True
    return ok, f"Supuesto 1. \n{detalle if ok else 'No se cumplen las condiciones para llegadas (valor y distribución Poisson/Exponencial).'}"
def verificar_supuesto_2_gui(params):
    t_serv = params.get("tasa_servicio_por_servidor", {}); t_e_serv = params.get("tiempo_servicio_por_servidor", {})
    val_ts = t_serv.get("valor"); dist_tasa = str(t_serv.get("distribucion", "")).lower()
    val_tes = t_e_serv.get("valor"); dist_tiempo = str(t_e_serv.get("distribucion", "")).lower()
    capacidad = params.get("capacidad_sistema", {}); capacidad_valor = capacidad.get("valor")
    detalle = ""; ok = False
    condicion_servicio_valida = (val_ts is not None and "poisson" in dist_tasa) or (val_tes is not None and "exponencial" in dist_tiempo)
    if condicion_servicio_valida:
        param_usado = "μ_n" if val_ts is not None else "μ_n"; dist_desc = "exponencial" 
        if capacidad_valor is not None and isinstance(capacidad_valor, (int, float)) and capacidad_valor > 0:
            detalle = f"Dado N(t) = n, la distribución de probabilidad actual del tiempo que falta para la próxima muerte (terminación de servicio) es {dist_desc} con parámetro {param_usado} (n = 1, ..., {int(capacidad_valor)})."
        else: detalle = f"Dado N(t) = n, la distribución de probabilidad actual del tiempo que falta para la próxima muerte (terminación de servicio) es {dist_desc} con parámetro {param_usado} (n = 1, ...)."
        ok = True
    return ok, f"Supuesto 2. \n{detalle if ok else 'No se cumplen las condiciones para servicios (valor y distribución Poisson/Exponencial).'}"
def verificar_supuesto_3_gui(s1_ok, s2_ok): 
    return s1_ok and s2_ok, ("Supuesto 3.\nLa variable aleatoria del supuesto 1 (el tiempo que falta hasta el próximo nacimiento) y la variable aleatoria del supuesto 2 (el tiempo que falta hasta la siguiente muerte) son mutuamente independientes. La siguiente transición del estado del proceso es\n n → n + 1 (un solo nacimiento)\no\n n → n - 1 (una sola muerte),\nlo que depende de cuál de las dos variables es más pequeña.")
def verificar_supuesto_4_gui(s3_ok): 
    return s3_ok, ("Supuesto 4.\nSe procederá cuando el sistema haya alcanzado la condición de estado estable (en caso de que pueda alcanzarla). Es decir, la tasa media a la que el proceso entra al estado n es igual a la tasa media a la que el proceso sale del estado n.")
def verificar_supuesto_5_gui(params):
    val_s = params.get("cantidad_servidores", {}).get("valor")
    ok = val_s is not None and isinstance(val_s, (int, float)) and val_s > 0
    return ok, f"Supuesto 5.\ns = {val_s if ok else 'No determinado o inválido'}"
def verificar_supuesto_6_gui(params): 
    val_k = params.get("capacidad_sistema", {}).get("valor")
    ok = False; detalle = "Supuesto 6.\n"
    if val_k is not None:
        if isinstance(val_k, str) and val_k.lower() == "infinita": detalle += "Capacidad del sistema: Infinita."; ok = True 
        elif isinstance(val_k, (int, float)) and val_k >= 0: detalle += f"Capacidad del sistema finita (K = {int(val_k)})."; ok = True
        else: detalle += "Capacidad del sistema no determinada o inválida."
    else: detalle += "Capacidad del sistema no determinada."
    return ok, detalle
def actualizar_supuestos_paso4(section_data_paso4, parametros_finales_paso3):
    text_widget = section_data_paso4.get('supuestos_text_widget')
    if not text_widget or not parametros_finales_paso3:
        if text_widget: text_widget.config(state='normal'); text_widget.delete('1.0', tk.END); text_widget.insert(tk.END, "Parámetros del Paso 3 no disponibles."); text_widget.config(state='disabled')
        return
    texto_final_supuestos = "SUPUESTOS DEL ENUNCIADO.\n"
    s1_ok, s1_texto = verificar_supuesto_1_gui(parametros_finales_paso3); texto_final_supuestos += f"{s1_texto}\n\n"
    s2_ok, s2_texto = verificar_supuesto_2_gui(parametros_finales_paso3); texto_final_supuestos += f"{s2_texto}\n\n"
    s3_ok, s3_texto = verificar_supuesto_3_gui(s1_ok, s2_ok); texto_final_supuestos += f"{s3_texto}\n\n"
    s4_ok, s4_texto = verificar_supuesto_4_gui(s3_ok); texto_final_supuestos += f"{s4_texto}\n\n"
    s5_ok, s5_texto = verificar_supuesto_5_gui(parametros_finales_paso3); texto_final_supuestos += f"{s5_texto}\n\n"
    s6_ok, s6_texto = verificar_supuesto_6_gui(parametros_finales_paso3); texto_final_supuestos += f"{s6_texto}\n"
    text_widget.config(state='normal'); text_widget.delete('1.0', tk.END); text_widget.insert(tk.END, texto_final_supuestos); text_widget.config(state='disabled')

# --- Funciones Auxiliares para Secciones Desplegables y UI (sin cambios) ---
def setup_placeholder(entry, placeholder_text):
    # ... (sin cambios)
    style = ttk.Style(); original_fg='black'
    try:
        fg_lookup = style.lookup('TEntry', 'foreground');
        if fg_lookup and str(fg_lookup) != COLOR_GRIS_TEXTO_PLACEHOLDER : original_fg = fg_lookup
        else: fg_lookup_general = style.lookup('.', 'foreground');
        if fg_lookup_general and str(fg_lookup_general) != COLOR_GRIS_TEXTO_PLACEHOLDER : original_fg = fg_lookup_general
    except tk.TclError: pass
    except Exception: pass
    if not hasattr(entry, 'placeholder_info'): entry.placeholder_info = {}
    entry.placeholder_info['original_fg'] = original_fg; entry.placeholder_info['text'] = placeholder_text
    entry.unbind("<FocusIn>")
    entry.unbind("<FocusOut>")
    def on_focusin(event, c_entry=entry, txt=placeholder_text, o_fg=original_fg):
        if c_entry.get() == txt and str(c_entry.cget('foreground')) == COLOR_GRIS_TEXTO_PLACEHOLDER:
            c_entry.delete(0, tk.END); c_entry.config(foreground=o_fg)
    def on_focusout(event, c_entry=entry, txt=placeholder_text, o_fg=original_fg):
        if not c_entry.get().strip():
            c_entry.delete(0, tk.END); c_entry.insert(0, txt); c_entry.config(foreground=COLOR_GRIS_TEXTO_PLACEHOLDER)
    current_text = entry.get()
    if not current_text.strip() or current_text == placeholder_text :
        entry.delete(0, tk.END)
        entry.insert(0, placeholder_text)
        entry.config(foreground=COLOR_GRIS_TEXTO_PLACEHOLDER)
    else: 
        entry.config(foreground=original_fg)
    entry.bind("<FocusIn>", on_focusin, add='+')
    entry.bind("<FocusOut>", on_focusout, add='+')
def _actualizar_estilo_header(section_data): 
    # ... (sin cambios)
    header_frame = section_data.get('header_frame'); widgets_in_header = section_data.get('widgets_in_header', [])
    if not header_frame: return
    if section_data.get('is_unlocked', False):
        header_frame.config(style="HeaderFrame.TFrame", cursor="hand2")
        for widget in widgets_in_header:
            if widget != header_frame: widget.config(style="HeaderLabel.TLabel", cursor="hand2")
    else:
        header_frame.config(style="LockedHeaderFrame.TFrame", cursor="arrow")
        for widget in widgets_in_header:
            if widget != header_frame: widget.config(style="LockedHeaderLabel.TLabel", cursor="arrow")
def _actualizar_estado_visual_seccion(section_data): 
    # ... (sin cambios)
    arrow_widget = section_data.get('arrow_widget')
    if section_data['is_expanded'] and section_data.get('is_unlocked', False):
        section_data['frame_contenido'].pack(fill=tk.BOTH, expand=True, padx=5, pady=(0, 5))
        if arrow_widget: arrow_widget.config(text="▲")
    else:
        section_data['frame_contenido'].pack_forget()
        if arrow_widget: arrow_widget.config(text="▼")
def actualizar_titulo_modelo_paso4(data_paso4, parametros_finales_paso3):
    # ... (sin cambios)
    label_modelo = data_paso4.get('label_titulo_modelo')
    if not label_modelo: return
    if not parametros_finales_paso3:
        label_modelo.config(text="Modelo de Colas: (Complete el Paso 3 primero)", foreground=COLOR_GRIS_TEXTO_SECUNDARIO)
        return
    try:
        exito_identificacion, resultado_str = calculator.identificar_modelo_cola(parametros_finales_paso3)
        if exito_identificacion:
            label_modelo.config(text=f"Los datos corresponden a un modelo: {resultado_str}", foreground=COLOR_TEXTO_EXITO)
        else:
            label_modelo.config(text=f"Análisis de modelo: {resultado_str}", foreground=COLOR_TEXTO_ADVERTENCIA)
    except AttributeError as e:
        error_msg = f"Error: Función 'identificar_modelo_cola' no encontrada o mal definida. ({e})"
        label_modelo.config(text=error_msg, foreground=COLOR_TEXTO_ADVERTENCIA)
    except Exception as e:
        error_msg = f"Error al identificar modelo: {e}"
        label_modelo.config(text="Modelo de Colas: Error en análisis.", foreground=COLOR_TEXTO_ADVERTENCIA)
def header_click_handler(event, section_data_clicked): 
    # ... (sin cambios)
    if section_data_clicked.get('is_unlocked', False):
        is_being_expanded = not section_data_clicked['is_expanded']
        section_data_clicked['is_expanded'] = is_being_expanded
        if is_being_expanded:
            paso_num = section_data_clicked.get('paso_numero')
            if paso_num == 2: cargar_y_mostrar_word_paso2(section_data_clicked)
            elif paso_num == 3: poblar_campos_paso3_desde_ai(section_data_clicked) # Esta llamada ahora es más inteligente
            elif paso_num == 4:
                if len(secciones_info) > 2 and secciones_info[2].get('parametros_consolidados_finales'):
                    actualizar_titulo_modelo_paso4(section_data_clicked, secciones_info[2]['parametros_consolidados_finales'])
                    actualizar_supuestos_paso4(section_data_clicked, secciones_info[2]['parametros_consolidados_finales'])
                else:
                    text_w = section_data_clicked.get('supuestos_text_widget')
                    if text_w: text_w.config(state='normal'); text_w.delete('1.0', tk.END); text_w.insert(tk.END, "Complete el Paso 3 para ver los supuestos."); text_w.config(state='disabled')
                    label_modelo = section_data_clicked.get('label_titulo_modelo')
                    if label_modelo: label_modelo.config(text="Modelo de Colas: (Complete el Paso 3 primero)", foreground=COLOR_GRIS_TEXTO_SECUNDARIO)
        _actualizar_estado_visual_seccion(section_data_clicked) 
    else: messagebox.showinfo("Paso Bloqueado", "Complete el paso anterior primero.")

def accion_principal_paso(section_data): 
    global nlp_sistema_listo
    action_btn = section_data.get('action_button_principal')
    if not action_btn: return
    btn_text = action_btn.cget('text')
    paso_titulo_completo = section_data.get('titulo_texto', "este paso")
    operacion_paso_especifico_exitosa = True
    mensaje_popup_exito = True

    if btn_text == "PROCESAR IMAGEN":
        # ... (sin cambios)
        if not tesseract_configurado_ok: messagebox.showerror("Error Tesseract", "Tesseract no configurado."); return
        ruta_img = section_data.get('ruta_imagen_seleccionada')
        if not ruta_img: messagebox.showerror("Error P1", "No imagen seleccionada."); return
        if ejecutar_flujo_completo_paso1(ruta_img, section_data): mensaje_popup_exito = "WORD #1 creado con éxito."
        else: operacion_paso_especifico_exitosa = False; return
    elif btn_text == "EXTRAER PARÁMETROS":
        # ... (sin cambios)
        mostrar_popup_cargando(root, "Inicializando IA NLP y extrayendo parámetros...")
        try:
            # global nlp_sistema_listo
            nlp_sistema_listo, mensaje_nlp = ai_nlp.inicializar_sistema_npl()
            if not nlp_sistema_listo:
                cerrar_popup_cargando()  # Cerrar el popup de "Procesando NLP..." antes de mostrar el de error/opción
                operacion_paso_especifico_exitosa = False

                comando_descarga_para_spacy = None
                tipo_modelo_error = None

                if "python -m spacy download es_core_news_sm" in mensaje_nlp:
                    comando_descarga_para_spacy = [sys.executable, "-m", "spacy", "download", "es_core_news_sm"]
                    tipo_modelo_error = 'spacy'
                elif "Sentence Transformers" in mensaje_nlp and \
                        any(keyword in mensaje_nlp.lower() for keyword in
                            ["descargar", "conexión", "cargar", "no se pudo cargar"]):
                    tipo_modelo_error = 'sentencetransformers'  # No hay comando, solo se reintenta

                if tipo_modelo_error:  # Si es un error conocido que podemos intentar solucionar
                    # mostrar_popup_opcion_descarga actualizará nlp_sistema_listo globalmente
                    # y retornará su nuevo estado.
                    if mostrar_popup_opcion_descarga(mensaje_nlp, comando_descarga_para_spacy, tipo_modelo_error):
                        # Si retorna True, nlp_sistema_listo es True.
                        # El usuario fue informado, debe reintentar la acción "Extraer Parámetros".
                        # No continuamos con la extracción en este mismo clic.
                        # Simplemente dejamos operacion_paso_especifico_exitosa en False para que no avance este paso.
                        # El mensaje en el popup ya le dijo que reintente.
                        print(
                            "INFO: NLP podría estar listo después de la intervención del usuario. Se requiere nuevo clic en 'Extraer Parámetros'.")
                    # Si retorna False, nlp_sistema_listo es False. Ya se mostró error.
                else:  # Error de NLP no manejable con descarga/reintento automático
                    messagebox.showerror("Error de Inicialización NLP", mensaje_nlp)

            if nlp_sistema_listo:
                texto_ocr_para_nlp = secciones_info[0].get('texto_ocr_obtenido', "") if secciones_info else ""
                if not texto_ocr_para_nlp:
                    messagebox.showwarning("Paso 2", "No hay texto OCR del Paso 1 para extraer parámetros.")
                    section_data['ai_output_paso2'] = {"parametros_extraidos": inicializar_estructura_parametros_ai()}
                else:
                    raw_ai_response_dict = ai_nlp.extraer_parametros_colas(texto_ocr_para_nlp, umbral_similitud_candidatas=0.50)
                    if isinstance(raw_ai_response_dict, dict) and "parametros_extraidos" in raw_ai_response_dict:
                        section_data['ai_output_paso2'] = raw_ai_response_dict;
                    else:
                        messagebox.showerror("Error AI-NLP", "Respuesta AI inesperada."); section_data['ai_output_paso2'] = {"parametros_extraidos": inicializar_estructura_parametros_ai()}; operacion_paso_especifico_exitosa = False
            else: operacion_paso_especifico_exitosa = False
        except AttributeError as e_attr: messagebox.showerror("Error AI_NLP", f"Función no encontrada en 'ai_nlp': {e_attr}"); operacion_paso_especifico_exitosa = False
        except Exception as e_ai_extract: messagebox.showerror("Error AI_NLP", f"Error durante NLP: {e_ai_extract}"); operacion_paso_especifico_exitosa = False
        finally: cerrar_popup_cargando()
        if operacion_paso_especifico_exitosa: mensaje_popup_exito = "Extracción de parámetros con IA finalizada."
        else: return
    elif btn_text == "INGRESAR DATOS AL MODELO": 
        # ... (sin cambios en la lógica interna, solo cómo se deshabilitan widgets después)
        parametros_finales = construir_json_final_paso3(section_data)
        if not parametros_finales:
            messagebox.showerror("Error Paso 3", "No se pudieron construir los parámetros finales del modelo.")
            operacion_paso_especifico_exitosa = False; return
        tasa_llegada_valor = parametros_finales.get("tasa_llegada", {}).get("valor")
        tiempo_llegadas_valor = parametros_finales.get("tiempo_entre_llegadas", {}).get("valor")
        if tasa_llegada_valor is None and tiempo_llegadas_valor is None:
            messagebox.showwarning("Datos Incompletos (Paso 3)", "No se ingresó información para la tasa de llegadas (λ) ni el tiempo entre llegadas.\nEl documento de supuestos podría no generarse correctamente o estar incompleto.")
        tasa_servicio_valor = parametros_finales.get("tasa_servicio_por_servidor", {}).get("valor")
        tiempo_servicio_valor = parametros_finales.get("tiempo_servicio_por_servidor", {}).get("valor")
        if tasa_servicio_valor is None and tiempo_servicio_valor is None:
            messagebox.showwarning("Datos Incompletos (Paso 3)", "No se ingresó información para la tasa de servicio (μ) ni el tiempo de servicio.\nEl documento de supuestos podría no generarse correctamente o estar incompleto.")
        nombre_doc2 = "WORD #2.docx"
        doc2_generado_ok = False
        try:
            doc2_generado_ok = document_generator.generar_doc_dos(parametros_finales, nombre_doc2, PROJECT_ROOT_DIR)
        except AttributeError: messagebox.showerror("Error de Módulo", "Función 'generar_doc_dos' no encontrada en 'document_generator'.")
        except Exception as e_gendoc2: messagebox.showerror("Error al Generar Documento", f"Error al generar '{nombre_doc2}':\n{e_gendoc2}")
        mensaje_popup_exito_final_paso = "" 
        if doc2_generado_ok:
            messagebox.showinfo("Documento Generado", f"'{nombre_doc2}' generado con éxito.") 

        if not operacion_paso_especifico_exitosa: return 
    
    if not operacion_paso_especifico_exitosa: return

    if section_data.get("paso_numero", 0) < 3:  # Solo para pasos 1, y 2
        messagebox.showinfo("Proceso Completado", mensaje_popup_exito)

    action_btn.config(state="disabled", bg=COLOR_BOTON_DESHABILITADO_BG, fg=COLOR_BOTON_DESHABILITADO_FG)
    for btn_s in section_data.get('botones_secundarios_a_deshabilitar', []): 
        btn_s.config(state="disabled", bg=COLOR_BOTON_DESHABILITADO_BG, fg=COLOR_BOTON_DESHABILITADO_FG)
    
    # Deshabilitar widgets de contenido del paso actual (MODIFICADO para no afectar Labels en Paso 3)
    if section_data.get('paso_numero') == 3:
        widgets_map_p3 = section_data.get('widgets_map_paso3', {})
        for widget_name, widget_obj in widgets_map_p3.items():
            if isinstance(widget_obj, (ttk.Entry, ttk.Combobox)): # Solo deshabilitar Entry y Combobox
                try:
                    widget_obj.config(state='disabled')
                except Exception as e: 
                    print(f"Adv:No se pudo deshabilitar {widget_obj}:{e}")
    else: # Lógica anterior para otros pasos
        widgets_a_deshabilitar_list = section_data.get('widgets_contenido_a_deshabilitar', [])
        for widget in widgets_a_deshabilitar_list:
            try:
                if isinstance(widget,(ttk.Entry, ttk.Combobox)): widget.config(state='disabled') 
                elif hasattr(widget,'config') and 'state' in widget.config(): widget.config(state="disabled")
            except Exception as e: print(f"Adv:No se pudo deshabilitar {widget}:{e}")

    if section_data['is_expanded'] and section_data.get('is_unlocked', False): 
        section_data['is_expanded'] = False
        _actualizar_estado_visual_seccion(section_data)
    
    try: # Lógica para avanzar al siguiente paso (sin cambios)
        current_idx = secciones_info.index(section_data)
        if current_idx + 1 < len(secciones_info):
            next_s_data = secciones_info[current_idx + 1]
            if not next_s_data.get('is_unlocked', False): 
                next_s_data['is_unlocked'] = True; _actualizar_estilo_header(next_s_data)
            if next_s_data.get('paso_numero') == 2: cargar_y_mostrar_word_paso2(next_s_data)
            elif next_s_data.get('paso_numero') == 3: 
                ai_data_for_step3 = section_data.get('ai_output_paso2')
                next_s_data['ai_parametros_prellenados'] = ai_data_for_step3 if ai_data_for_step3 else {"parametros_extraidos": inicializar_estructura_parametros_ai()}
                poblar_campos_paso3_desde_ai(next_s_data) 
            elif next_s_data.get('paso_numero') == 4: 
                params_finales_paso3 = section_data.get('parametros_consolidados_finales')
                actualizar_titulo_modelo_paso4(next_s_data, params_finales_paso3)
                actualizar_supuestos_paso4(next_s_data, params_finales_paso3)
            if not next_s_data['is_expanded']: 
                next_s_data['is_expanded'] = True; _actualizar_estado_visual_seccion(next_s_data) 
    except ValueError: pass 
    except Exception as e_unlock: print(f"Error al desbloquear/poblar siguiente paso: {e_unlock}")

# --- Funciones de creación de UI (contenido_paso1, 2, 3, 4 y crear_seccion_desplegable)
# (contenido_paso3 sin cambios estructurales, las correcciones son en poblar y accion_paso)
def crear_seccion_desplegable(master, titulo_sin_paso, contenido_callback, estado_inicial=False):
    # ... (sin cambios)
    frame_externo = ttk.Frame(master); frame_externo.pack(fill=tk.X, pady=(0, 10), padx=10)
    current_section_data = {}; paso_numero = len(secciones_info) + 1
    is_initially_unlocked = (paso_numero == 1)
    header_frame = ttk.Frame(frame_externo); header_frame.pack(fill=tk.X)
    arrow_label = ttk.Label(header_frame, text="▲" if estado_inicial and is_initially_unlocked else "▼")
    arrow_label.pack(side=tk.LEFT, padx=(10, 0), pady=6)
    paso_text_label = ttk.Label(header_frame, text=f"Paso {paso_numero}")
    paso_text_label.pack(side=tk.LEFT, padx=(5,0), pady=6)
    separator_label = ttk.Label(header_frame, text="."); separator_label.pack(side=tk.LEFT, pady=6)
    title_label = ttk.Label(header_frame, text=f" {titulo_sin_paso}")
    title_label.pack(side=tk.LEFT, padx=(0,10), pady=6, fill=tk.X, expand=True)
    widgets_in_header_list = [header_frame, arrow_label, paso_text_label, separator_label, title_label]
    for widget in widgets_in_header_list:
        widget.bind("<Button-1>", lambda e, sd=current_section_data: header_click_handler(e, sd))
    frame_contenido = ttk.Frame(frame_externo, relief="groove", borderwidth=2, padding=(10, 10, 10, 0))
    current_section_data.update({
        'paso_numero': paso_numero, 'header_frame': header_frame, 'arrow_widget': arrow_label,
        'widgets_in_header': widgets_in_header_list, 'frame_contenido': frame_contenido,
        'titulo_texto': f"Paso {paso_numero}. {titulo_sin_paso}",
        'is_expanded': estado_inicial and is_initially_unlocked, 'is_unlocked': is_initially_unlocked,
        'action_button_principal': None, 'ruta_imagen_seleccionada': None,
        'texto_ocr_obtenido': None, 'ai_output_paso2': None, 'ai_parametros_prellenados': None,
        'botones_secundarios_a_deshabilitar': [], 'widgets_contenido_a_deshabilitar': [],
        'word_title_label': None, 'word_text_widget': None, 'widgets_map_paso3': {},
        'parametros_consolidados_finales': None, 'supuestos_text_widget': None,
        'arrival_is_rate': True, 'service_is_time': True 
    })
    contenido_callback(frame_contenido, current_section_data)
    _actualizar_estilo_header(current_section_data); _actualizar_estado_visual_seccion(current_section_data)
    secciones_info.append(current_section_data); return current_section_data
def seleccionar_archivo_imagen(label_status_imagen, section_data_paso1, frame_contenido_paso1): 
    # ... (sin cambios)
    extensiones_validas_display = "*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff"; extensiones_validas_check = ('.png', '.jpg', '.jpeg', '.bmp', '.tif', '.tiff')
    try:
        carpeta_images_inicial = os.path.join(PROJECT_ROOT_DIR, "images")
        if not os.path.exists(carpeta_images_inicial): os.makedirs(carpeta_images_inicial, exist_ok=True)
        ruta_imagen = filedialog.askopenfilename(parent=root, title="Selecciona la imagen", initialdir=carpeta_images_inicial,
            filetypes=[("Archivos de imagen", extensiones_validas_display), ("Todos los archivos", "*.*")])
        wraplength_dinamico = 580
        if not ruta_imagen:
            label_status_imagen.config(text="No se seleccionó ningún archivo.", foreground=COLOR_GRIS_TEXTO_SECUNDARIO, wraplength=wraplength_dinamico)
            section_data_paso1['ruta_imagen_seleccionada'] = None; return None
        if not ruta_imagen.lower().endswith(extensiones_validas_check):
            label_status_imagen.config(text=f"Error: Formato no válido.", foreground=COLOR_TEXTO_ADVERTENCIA, wraplength=wraplength_dinamico)
            section_data_paso1['ruta_imagen_seleccionada'] = None; return None
        nombre_archivo = os.path.basename(ruta_imagen)
        label_status_imagen.config(text=f"Imagen: \"{nombre_archivo}\" agregada.", foreground=COLOR_TEXTO_EXITO, wraplength=wraplength_dinamico)
        section_data_paso1['ruta_imagen_seleccionada'] = ruta_imagen; return ruta_imagen
    except Exception as e:
        messagebox.showerror("Error al Seleccionar Archivo", f"Error: {str(e)}"); label_status_imagen.config(text="Error al seleccionar.", foreground=COLOR_TEXTO_ADVERTENCIA, wraplength=wraplength_dinamico)
        section_data_paso1['ruta_imagen_seleccionada'] = None; return None
def contenido_paso1(frame_contenido, section_data): 
    # ... (sin cambios)
    label_estado_imagen = ttk.Label(frame_contenido, text="Aún no se ha seleccionado ninguna imagen.", foreground=COLOR_GRIS_TEXTO_SECUNDARIO, font=FONT_NORMAL, wraplength=580, justify="center", anchor="center")
    label_estado_imagen.pack(pady=(0,10), fill=tk.X)
    btn_agregar = tk.Button(frame_contenido, text="AGREGAR IMAGEN", relief="solid", borderwidth=1, bg=COLOR_BOTON_MINIMALISTA_BG, fg=COLOR_BOTON_MINIMALISTA_FG, activebackground=COLOR_BOTON_MINIMALISTA_ACTIVE_BG, activeforeground=COLOR_BOTON_MINIMALISTA_FG, highlightthickness=1, highlightbackground=COLOR_BOTON_MINIMALISTA_BORDER, font=FONT_NORMAL, pady=5, cursor="hand2", command=lambda: seleccionar_archivo_imagen(label_estado_imagen, section_data, frame_contenido))
    btn_agregar.pack(pady=(5,5))
    section_data['botones_secundarios_a_deshabilitar'].append(btn_agregar)
    ttk.Label(frame_contenido, text="Formatos soportados: png, jpg, jpeg, bmp, tif, tiff", foreground=COLOR_GRIS_TEXTO_SECUNDARIO, font=FONT_NORMAL, justify="center", anchor="center").pack(pady=(0,10), fill=tk.X)
    btn_procesar = tk.Button(frame_contenido, text="PROCESAR IMAGEN", relief="raised", borderwidth=1, bg=COLOR_BOTON_ACCION_PRINCIPAL_AZUL, fg=COLOR_TEXTO_BOTON_AZUL, highlightthickness=0, font=FONT_BUTTON_ACTION_MAIN, cursor="hand2")
    btn_procesar.pack(pady=(10,5), fill=tk.X, padx=20, ipady=4)
    section_data['action_button_principal'] = btn_procesar; btn_procesar.config(command=lambda: accion_principal_paso(section_data))
def contenido_paso2(frame, section_data): 
    # ... (sin cambios)
    label_titulo_word = ttk.Label(frame, text="Esperando documento...", font=FONT_SUB_HEADER, foreground=COLOR_GRIS_TEXTO_SECUNDARIO, wraplength=600)
    label_titulo_word.pack(anchor="w", pady=(0,5), fill=tk.X); section_data['word_title_label'] = label_titulo_word
    text_area_frame = ttk.Frame(frame); text_area_frame.pack(fill=tk.BOTH, expand=True, pady=(0,5))
    v_scrollbar = ttk.Scrollbar(text_area_frame, orient=tk.VERTICAL); v_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    text_widget_word = tk.Text(text_area_frame, wrap=tk.WORD, yscrollcommand=v_scrollbar.set, font=FONT_NORMAL, height=10, relief="flat", borderwidth=0, padx=5, pady=5, state='disabled', background=root.cget('bg'))
    text_widget_word.pack(side=tk.LEFT, fill=tk.BOTH, expand=True); v_scrollbar.config(command=text_widget_word.yview)
    section_data['word_text_widget'] = text_widget_word
    ttk.Label(frame, text="⚠️ Si detecta errores en la transcripción, verifique la imagen original o modifique el doc Word #1 antes de continuar.", foreground=COLOR_TEXTO_ADVERTENCIA, wraplength=600, justify="left", font=FONT_NORMAL).pack(anchor="w", pady=(5,10), fill=tk.X)
    btn_extraer = tk.Button(frame, text="EXTRAER PARÁMETROS", relief="raised", borderwidth=1, bg=COLOR_BOTON_ACCION_PRINCIPAL_AZUL, fg=COLOR_TEXTO_BOTON_AZUL, highlightthickness=0, font=FONT_BUTTON_ACTION_MAIN, cursor="hand2")
    btn_extraer.pack(pady=5, fill=tk.X, padx=20, ipady=4)
    section_data['action_button_principal'] = btn_extraer; btn_extraer.config(command=lambda: accion_principal_paso(section_data))
def contenido_paso3(frame, section_data): 
    # ... (sin cambios estructurales, la UI es la misma que la versión anterior que te gustó)
    common_entry_width = 18
    widgets_map = {}
    frame_llegadas = ttk.Frame(frame); frame_llegadas.pack(fill=tk.X, pady=3)
    label_llegadas = ttk.Label(frame_llegadas, text="Tasa de llegadas (λ):", font=FONT_NORMAL)
    label_llegadas.pack(side="left", padx=(0,5)); widgets_map['label_llegadas'] = label_llegadas
    entry_llegadas_valor = ttk.Entry(frame_llegadas, width=common_entry_width, font=FONT_PLACEHOLDER)
    entry_llegadas_valor.pack(side="left", padx=5); setup_placeholder(entry_llegadas_valor, PLACEHOLDER_EJ_20)
    widgets_map['entry_llegadas_valor'] = entry_llegadas_valor
    combo_llegadas_unidad = ttk.Combobox(frame_llegadas, values=DEFAULT_RATE_UNITS, width=17, state="readonly", font=FONT_NORMAL)
    combo_llegadas_unidad.pack(side="left", padx=5); combo_llegadas_unidad.set(DEFAULT_LAMBDA_UNIT_SELECTION)
    widgets_map['combo_llegadas_unidad'] = combo_llegadas_unidad
    frame_servicios = ttk.Frame(frame); frame_servicios.pack(fill=tk.X, pady=3)
    label_servicios = ttk.Label(frame_servicios, text="Tiempo de servicio (1/μ):", font=FONT_NORMAL)
    label_servicios.pack(side="left", padx=(0,5)); widgets_map['label_servicios'] = label_servicios
    entry_servicios_valor = ttk.Entry(frame_servicios, width=common_entry_width, font=FONT_PLACEHOLDER)
    entry_servicios_valor.pack(side="left", padx=5); setup_placeholder(entry_servicios_valor, PLACEHOLDER_INGRESE_VALOR)
    widgets_map['entry_servicios_valor'] = entry_servicios_valor
    combo_servicios_unidad = ttk.Combobox(frame_servicios, values=DEFAULT_TIME_UNITS, width=12, state="readonly", font=FONT_NORMAL)
    combo_servicios_unidad.pack(side="left", padx=5); combo_servicios_unidad.set(DEFAULT_MU_TIME_UNIT_SELECTION)
    widgets_map['combo_servicios_unidad'] = combo_servicios_unidad
    frame_s = ttk.Frame(frame); frame_s.pack(fill=tk.X, pady=3) 
    ttk.Label(frame_s, text="Servidores en paralelo (s):", font=FONT_NORMAL).pack(side="left", padx=(0,5))
    entry_s = ttk.Entry(frame_s, width=common_entry_width, font=FONT_PLACEHOLDER) 
    entry_s.pack(side="left", padx=5); setup_placeholder(entry_s, PLACEHOLDER_INGRESE_VALOR)
    widgets_map['entry_s'] = entry_s
    frame_k = ttk.Frame(frame); frame_k.pack(fill=tk.X, pady=3) 
    ttk.Label(frame_k, text="Capacidad del sistema (K):", font=FONT_NORMAL).pack(side="left", padx=(0,5))
    entry_k = ttk.Entry(frame_k, width=common_entry_width, font=FONT_PLACEHOLDER) 
    entry_k.pack(side="left", padx=5); setup_placeholder(entry_k, PLACEHOLDER_INGRESE_VALOR)
    widgets_map['entry_k'] = entry_k
    section_data['widgets_map_paso3'] = widgets_map
    btn_ingresar_modelo = tk.Button(frame, text="INGRESAR DATOS AL MODELO", relief="raised", borderwidth=1, bg=COLOR_BOTON_ACCION_PRINCIPAL_AZUL, fg=COLOR_TEXTO_BOTON_AZUL, highlightthickness=0, font=FONT_BUTTON_ACTION_MAIN, cursor="hand2")
    btn_ingresar_modelo.pack(pady=(15,5), fill=tk.X, padx=20, ipady=4)
    section_data['action_button_principal'] = btn_ingresar_modelo
    btn_ingresar_modelo.config(command=lambda: accion_principal_paso(section_data))
def contenido_paso4(frame, section_data):
    label_modelo_identificado = ttk.Label(frame, text="Modelo de Colas: (Analizando...)", font=FONT_SECTION_HEADER, foreground=COLOR_GRIS_TEXTO_SECUNDARIO, justify="center", anchor="center", wraplength=650)
    label_modelo_identificado.pack(pady=(0,10), fill=tk.X)
    section_data['label_titulo_modelo'] = label_modelo_identificado 
    
    supuestos_frame = ttk.Frame(frame)
    supuestos_frame.pack(pady=(5,10), fill=tk.BOTH, expand=True)
    supuestos_scrollbar = ttk.Scrollbar(supuestos_frame, orient=tk.VERTICAL)
    supuestos_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    supuestos_text_widget = tk.Text(supuestos_frame, wrap=tk.WORD, yscrollcommand=supuestos_scrollbar.set, font=FONT_NORMAL, height=10, relief="solid", borderwidth=1, padx=5, pady=5, state='disabled', background="#fdfdfd") # Ajusta height si es necesario
    supuestos_text_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    supuestos_scrollbar.config(command=supuestos_text_widget.yview)
    section_data['supuestos_text_widget'] = supuestos_text_widget
    supuestos_text_widget.config(state='normal')
    supuestos_text_widget.insert(tk.END, "Complete el Paso 3 para verificar y mostrar los supuestos del modelo aquí.")
    supuestos_text_widget.config(state='disabled')
    
    ttk.Label(frame, text="Seleccione que desea calcular:", justify="center", anchor="center", font=FONT_NORMAL).pack(pady=(5,8), fill=tk.X)
    frame_botones_calculo = ttk.Frame(frame)
    frame_botones_calculo.pack(pady=5)
    
    btn_medidas = tk.Button(frame_botones_calculo, text="Medidas de desempeño", 
                            relief="raised", borderwidth=1, pady=3, padx=10, 
                            font=FONT_NORMAL, bg=COLOR_BOTON_MINIMALISTA_BG, 
                            fg=COLOR_BOTON_MINIMALISTA_FG, cursor="hand2",
                            command=lambda: abrir_popup_medidas_desempeno(secciones_info[2].get('parametros_consolidados_finales'))
                           )
    btn_medidas.pack(side="left", padx=5)
    section_data['btn_medidas_desempeno'] = btn_medidas # Guardar referencia si es necesario

    btn_probabilidad = tk.Button(frame_botones_calculo, text="Probabilidad de \"n\" clientes", 
                                 relief="raised", borderwidth=1, pady=3, padx=10, 
                                 font=FONT_NORMAL, bg=COLOR_BOTON_MINIMALISTA_BG, 
                                 fg=COLOR_BOTON_MINIMALISTA_FG, cursor="hand2")
    btn_probabilidad.pack(side="left", padx=5)
    # btn_probabilidad.config(command=lambda: TU_FUNCION_PROBABILIDAD_N_CLIENTES()) # Para el futuro
    section_data['btn_probabilidad_n'] = btn_probabilidad

# --- Funciones para Reset y "Acerca de" (sin cambios) ---
def mostrar_info_proyecto():
    info_titulo = "Acerca del proyecto"; info_texto = config.PROJECT_INFO
    info_popup = tk.Toplevel(root); info_popup.title(info_titulo); info_popup.transient(root); info_popup.grab_set()
    info_popup.geometry("450x250"); info_popup.resizable(False, False)
    root.update_idletasks(); x_r=root.winfo_x(); y_r=root.winfo_y(); w_r=root.winfo_width(); h_r=root.winfo_height()
    w_p=450; h_p=250; x_p=x_r+(w_r//2)-(w_p//2); y_p=y_r+(h_r//2)-(h_p//2); info_popup.geometry(f"{w_p}x{h_p}+{x_p}+{y_p}")
    msg_f = ttk.Frame(info_popup, padding=(10,10,10,0)); msg_f.pack(expand=True, fill="both")
    ttk.Label(msg_f, text=info_texto, justify=tk.LEFT, font=FONT_NORMAL).pack(anchor="w", pady=(0,10))
    ttk.Button(msg_f, text="OK", command=info_popup.destroy, style="Accent.TButton").pack(pady=10); info_popup.wait_window()
def reiniciar_aplicacion():
    # ... (sin cambios)
    global nlp_sistema_listo; nlp_sistema_listo = False
    for i, sd in enumerate(secciones_info):
        if sd.get('action_button_principal'): sd['action_button_principal'].config(state="normal", bg=COLOR_BOTON_ACCION_PRINCIPAL_AZUL, fg=COLOR_TEXTO_BOTON_AZUL)
        for btn_sec in sd.get('botones_secundarios_a_deshabilitar', []): btn_sec.config(state="normal", bg=COLOR_BOTON_MINIMALISTA_BG, fg=COLOR_BOTON_MINIMALISTA_FG)
        if sd.get('paso_numero') == 1:
            sd['ruta_imagen_seleccionada'] = None; sd['texto_ocr_obtenido'] = None; sd['texto_ocr_original_para_word1'] = None
            for child in sd['frame_contenido'].winfo_children(): 
                if isinstance(child, ttk.Label) and ("Aún no se ha seleccionado" in child.cget("text") or "Imagen:" in child.cget("text") or "Error" in child.cget("text")):
                    child.config(text="Aún no se ha seleccionado ninguna imagen.", foreground=COLOR_GRIS_TEXTO_SECUNDARIO); break
        elif sd.get('paso_numero') == 2:
            sd['ai_output_paso2'] = None
            if sd.get('word_title_label'): sd['word_title_label'].config(text="Esperando documento...")
            if sd.get('word_text_widget'): wtw = sd['word_text_widget']; wtw.config(state='normal'); wtw.delete('1.0', tk.END); wtw.config(state='disabled')
        elif sd.get('paso_numero') == 3:
            sd['ai_parametros_prellenados'] = None; sd['parametros_consolidados_finales'] = None
            sd['arrival_is_rate'] = True; sd['service_is_time'] = True 
            widgets_map_p3 = sd.get('widgets_map_paso3', {})
            if widgets_map_p3:
                if 'label_llegadas' in widgets_map_p3: widgets_map_p3['label_llegadas'].config(text="Tasa de llegadas (λ):")
                if 'entry_llegadas_valor' in widgets_map_p3: 
                    entry_l = widgets_map_p3['entry_llegadas_valor']
                    entry_l.config(state='normal'); entry_l.delete(0,tk.END); setup_placeholder(entry_l, PLACEHOLDER_EJ_20)
                if 'combo_llegadas_unidad' in widgets_map_p3:
                    combo_l = widgets_map_p3['combo_llegadas_unidad']
                    combo_l.config(state='readonly', values=DEFAULT_RATE_UNITS); combo_l.set(DEFAULT_LAMBDA_UNIT_SELECTION)
                if 'label_servicios' in widgets_map_p3: widgets_map_p3['label_servicios'].config(text="Tiempo de servicio:")
                if 'entry_servicios_valor' in widgets_map_p3:
                    entry_serv = widgets_map_p3['entry_servicios_valor']
                    entry_serv.config(state='normal'); entry_serv.delete(0,tk.END); setup_placeholder(entry_serv, PLACEHOLDER_INGRESE_VALOR)
                if 'combo_servicios_unidad' in widgets_map_p3:
                    combo_serv = widgets_map_p3['combo_servicios_unidad']
                    combo_serv.config(state='readonly', values=DEFAULT_TIME_UNITS); combo_serv.set(DEFAULT_MU_TIME_UNIT_SELECTION)
                for name, placeholder in [('entry_s', PLACEHOLDER_INGRESE_VALOR), ('entry_k', PLACEHOLDER_INGRESE_VALOR)]:
                    if name in widgets_map_p3:
                        entry_widget = widgets_map_p3[name]
                        entry_widget.config(state='normal'); entry_widget.delete(0, tk.END); setup_placeholder(entry_widget, placeholder)
                # Habilitar todos los Entries y Comboboxes explícitamente
                for widget_name, widget_obj in widgets_map_p3.items():
                     if isinstance(widget_obj, ttk.Entry): widget_obj.config(state='normal')
                     elif isinstance(widget_obj, ttk.Combobox): widget_obj.config(state='readonly')
        elif sd.get('paso_numero') == 4:
            if sd.get('label_titulo_modelo'): sd['label_titulo_modelo'].config(text="Modelo de Colas: (Complete el Paso 3 primero)", foreground=COLOR_GRIS_TEXTO_SECUNDARIO)
            sup_widget = sd.get('supuestos_text_widget')
            if sup_widget: sup_widget.config(state='normal'); sup_widget.delete('1.0', tk.END); sup_widget.insert(tk.END, "Complete el Paso 3 para verificar y mostrar los supuestos del modelo aquí."); sup_widget.config(state='disabled')
        sd['is_unlocked'] = (i == 0); sd['is_expanded'] = (i == 0)
        _actualizar_estilo_header(sd); _actualizar_estado_visual_seccion(sd)
    if root.winfo_exists(): messagebox.showinfo("Reinicio", "Proceso reiniciado.")


# --- Crear Ventana Principal y Estilos ---
root = tk.Tk()
root.title(config.PROJECT_NAME); root.minsize(720, 780); root.configure(bg=ROOT_BG_COLOR)
style = ttk.Style()
style.theme_use('clam') 
style.configure("HeaderFrame.TFrame", background=COLOR_HEADER_ACTIVE_BG, relief="raised", borderwidth=1)
style.configure("HeaderLabel.TLabel", background=COLOR_HEADER_ACTIVE_BG, foreground=COLOR_HEADER_ACTIVE_FG)
style.configure("LockedHeaderFrame.TFrame", background=COLOR_HEADER_LOCKED_BG, relief="flat", borderwidth=1)
style.configure("LockedHeaderLabel.TLabel", background=COLOR_HEADER_LOCKED_BG, foreground=COLOR_HEADER_LOCKED_FG)
style.configure('.', font=FONT_NORMAL, background=ROOT_BG_COLOR) # Aplicar fondo a más widgets por defecto
style.configure('TButton', font=FONT_NORMAL)
style.configure('TLabel', font=FONT_NORMAL, background=ROOT_BG_COLOR) # Asegurar que Labels tengan el fondo correcto
style.configure('TEntry', font=FONT_PLACEHOLDER)
style.configure('TCombobox', font=FONT_NORMAL); style.configure("Accent.TButton", font=FONT_BOLD, padding=5)
style.map('TCombobox', fieldbackground=[('readonly', 'white')]) 
style.map('TEntry', fieldbackground=[('disabled', ROOT_BG_COLOR)]) 
style.map('TCombobox', fieldbackground=[('disabled', ROOT_BG_COLOR)])
style.map('TCombobox', selectbackground=[('readonly', 'white')]) 
style.map('TCombobox', selectforeground=[('readonly', 'black')])

# Estilo para el frame de botones superiores
style.configure("TopButtons.TFrame", background=ROOT_BG_COLOR)


root.option_add("*TCombobox*Listbox*Font", FONT_NORMAL)
titulo_label = ttk.Label(root, text=config.PROJECT_TITLE, font=FONT_MAIN_TITLE) # Usará el background del estilo '.'
titulo_label.pack(pady=(15, 10))

top_buttons_frame = ttk.Frame(root, style="TopButtons.TFrame") # Aplicar estilo
top_buttons_frame.pack(pady=(0, 15), fill=tk.X, padx=10)

btn_about = ttk.Button(top_buttons_frame, text="Acerca de", command=mostrar_info_proyecto, style="Toolbutton.TButton")
btn_about.pack(side=tk.RIGHT, padx=(5,0))
btn_reset = ttk.Button(top_buttons_frame, text="Reiniciar proceso", command=reiniciar_aplicacion, style="Toolbutton.TButton")
btn_reset.pack(side=tk.RIGHT, padx=(0,5))

# --- Crear Pasos Desplegables ---
crear_seccion_desplegable(root, "Adjuntar imagen.", contenido_paso1, estado_inicial=True)
crear_seccion_desplegable(root, "Vista previa del documento WORD #1 generado.", contenido_paso2)
crear_seccion_desplegable(root, "Datos extraídos.", contenido_paso3)
crear_seccion_desplegable(root, "Modelo de teoría de colas.", contenido_paso4)

root.mainloop()