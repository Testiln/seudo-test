import re
import pytesseract

def extraer_texto(img_proc):
    try:
        texto_transcrito = pytesseract.image_to_string(img_proc, lang='spa')
        # Quitar guiones al final de las lineas
        texto_transcrito = re.sub(r'-\n', '', texto_transcrito)
        # Unir lineas que no terminen en puntuación
        texto_transcrito = re.sub(r'(?<![\.\!\?])\n(?!\n)', ' ', texto_transcrito)
        # Corrección de puntuación por defecto
        texto_transcrito = re.sub(r'\.(?=\s?[a-záéíóúñ])', ',', texto_transcrito)
        texto_transcrito = re.sub(r',(?=\s?[A-ZÁÉÍÓÚÑ])', '.', texto_transcrito)
        if not texto_transcrito.strip(): 
            return "OCR", "OCR no extrajo texto. WORD #1 en blanco."
        return texto_transcrito
    except pytesseract.TesseractNotFoundError: 
        return False, "Error Tesseract", "Tesseract no instalado/PATH."
    except pytesseract.TesseractError as e:
        msg = f"Error Tesseract OCR: {e}"
        if "language 'spa' is not supported" in str(e).lower() or "error opening data file" in str(e).lower():
            msg = "Error: Paquete idioma 'spa' Tesseract no instalado."
        print(msg)
        return False, "Error Tesseract", msg
    except Exception as e: 
        msg = f"Error OCR: {e}"
        print(msg)
        return False, "Error OCR", msg