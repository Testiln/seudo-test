import math # Para math.isclose en lugar de epsilon para flotantes

# --- Factores de Conversión a HORAS ---
CONVERSION_A_HORAS = {
    "segundo": 1.0 / 3600.0,
    "segundos": 1.0 / 3600.0,
    "minuto": 1.0 / 60.0,
    "minutos": 1.0 / 60.0,
    "hora": 1.0,
    "horas": 1.0,
    "dia": 24.0,
    "dias": 24.0,
    "día": 24.0,
    "días": 24.0,
    "mes": 24.0 * 30.0,
    "meses": 24.0 * 30.0,
    "año": 24.0 * 365.0,
    "años": 24.0 * 365.0,
}

def _extraer_unidad_tiempo_base(unidad_str: str | None) -> str | None:
    """Extrae la parte de la unidad de tiempo (ej. 'hora' de 'clientes/hora' o 'minutos' de 'minutos')."""
    if not unidad_str or not isinstance(unidad_str, str):
        return None
    unidad_limpia = unidad_str.lower().strip()
    if "/" in unidad_limpia: # Formato tasa: "algo/unidad_tiempo"
        partes = unidad_limpia.split('/')
        if len(partes) == 2:
            return partes[1]
    else: # Formato tiempo: "unidad_tiempo"
        return unidad_limpia
    return None

def _normalizar_a_tasa_horaria(valor: float | None, unidad_str: str | None, es_tasa_directa: bool) -> float | None:
    """
    Convierte un valor (ya sea una tasa o un tiempo) a una tasa en eventos por HORA.
    Si es_tasa_directa es True, valor es una tasa (ej. clientes/unidad_str).
    Si es_tasa_directa es False, valor es un tiempo (ej. unidad_str por cliente).
    """
    if valor is None or not isinstance(valor, (int, float)) or valor <= 0:
        return None
    
    unidad_tiempo_base = _extraer_unidad_tiempo_base(unidad_str)
    
    if not unidad_tiempo_base:
        print(f"ADVERTENCIA (Normalización): Unidad de tiempo no reconocida o ausente en '{unidad_str}'. No se puede normalizar el valor {valor}.")
        return None # No se puede normalizar sin una unidad de tiempo clara

    factor_a_horas = CONVERSION_A_HORAS.get(unidad_tiempo_base)

    if factor_a_horas is None:
        print(f"ADVERTENCIA (Normalización): Factor de conversión no encontrado para unidad '{unidad_tiempo_base}'. No se puede normalizar el valor {valor} {unidad_str}.")
        return None

    if es_tasa_directa:
        # valor está en eventos POR unidad_tiempo_base (que dura factor_a_horas)
        return valor / factor_a_horas
    else:
        # valor es un tiempo (ej. tiempo de servicio) en unidad_tiempo_base
        tiempo_en_horas = valor * factor_a_horas
        if tiempo_en_horas <= 0:
            return None
        return 1.0 / tiempo_en_horas

def _get_lambda_eff(params: dict) -> float | None:
    tasa_llegada_info = params.get("tasa_llegada", {})
    tiempo_llegadas_info = params.get("tiempo_entre_llegadas", {})
    
    val_tasa = tasa_llegada_info.get("valor")
    uni_tasa = tasa_llegada_info.get("unidades")
    val_tiempo = tiempo_llegadas_info.get("valor")
    uni_tiempo = tiempo_llegadas_info.get("unidades")

    if isinstance(val_tasa, (int, float)) and val_tasa > 0:
        return _normalizar_a_tasa_horaria(val_tasa, uni_tasa, es_tasa_directa=True)
    elif isinstance(val_tiempo, (int, float)) and val_tiempo > 0:
        return _normalizar_a_tasa_horaria(val_tiempo, uni_tiempo, es_tasa_directa=False)
    return None

def _get_mu_rate_eff(params: dict) -> float | None:
    tasa_servicio_info = params.get("tasa_servicio_por_servidor", {})
    tiempo_servicio_info = params.get("tiempo_servicio_por_servidor", {})

    val_tasa = tasa_servicio_info.get("valor")
    uni_tasa = tasa_servicio_info.get("unidades")
    val_tiempo = tiempo_servicio_info.get("valor")
    uni_tiempo = tiempo_servicio_info.get("unidades")

    # Si la IA provee tasa de servicio, usarla. Si no, calcularla desde tiempo de servicio.
    if isinstance(val_tasa, (int, float)) and val_tasa > 0:
        return _normalizar_a_tasa_horaria(val_tasa, uni_tasa, es_tasa_directa=True)
    elif isinstance(val_tiempo, (int, float)) and val_tiempo > 0:
        return _normalizar_a_tasa_horaria(val_tiempo, uni_tiempo, es_tasa_directa=False)
    return None

def _validar_parametros_base_para_rho(lambda_eff: float | None, mu_rate_eff: float | None, num_s: int | None) -> bool:
    if lambda_eff is None:
        return False
    if mu_rate_eff is None:
        return False
    if num_s is None:
        return False
    return True # Todas las necesarias para rho están presentes y son numéricas

def _es_capacidad_infinita(params: dict) -> bool: 
    cap_sis_info = params.get("capacidad_sistema", {})
    valor_k = cap_sis_info.get("valor")
    if valor_k is None: 
        return True
    if isinstance(valor_k, str) and valor_k.lower() == "infinita": 
        return True
    return False

def _es_capacidad_finita_valida(params: dict) -> tuple[bool, int | None]: 
    cap_sis_info = params.get("capacidad_sistema", {})
    valor_k = cap_sis_info.get("valor")
    if valor_k is None: 
        return False, None
    if isinstance(valor_k, str) and valor_k.lower() == "infinita": 
        return False, None
    if isinstance(valor_k, (int, float)) and valor_k >= 0: 
        return True, int(valor_k)
    return False, None

def _get_numero_servidores(params: dict) -> int | None: 
    s_info = params.get("cantidad_servidores", {})
    s_valor_raw = s_info.get("valor")
    if isinstance(s_valor_raw, (int, float)) and s_valor_raw >= 1: 
        return int(s_valor_raw)
    return None

def _check_mm1(params: dict, num_servidores: int) -> bool: 
    return num_servidores == 1 and _es_capacidad_infinita(params)

def calcular_medidas_mm1(parametros_finales: dict) -> dict | str:
    """
    Calcula las principales medidas de desempeño para un modelo de colas M/M/1.
    Utiliza _get_lambda_eff y _get_mu_rate_eff para obtener tasas normalizadas (ej. por hora).

    Args:
        parametros_finales (dict): El diccionario consolidado de parámetros
                                   (la estructura que contiene "tasa_llegada", 
                                    "tiempo_servicio_por_servidor", etc.).

    Returns:
        dict: Un diccionario con las medidas de desempeño si el sistema es estable.
        str: Un mensaje de error si los parámetros son inválidos o el sistema es inestable.
    """
    # Obtener tasas normalizadas usando las funciones existentes en este módulo
    lambda_val = _get_lambda_eff(parametros_finales)
    mu_val = _get_mu_rate_eff(parametros_finales) # Tasa de servicio por servidor

    if lambda_val is None:
        return "Error (M/M/1): Tasa de llegada (lambda) no pudo ser determinada o normalizada."
    if mu_val is None:
        return "Error (M/M/1): Tasa de servicio (mu) no pudo ser determinada o normalizada."

    # La validación de > 0 ya está implícita en _get_lambda_eff y _get_mu_rate_eff si devuelven un valor
    
    # Para M/M/1, el número de servidores (s) es 1.
    # Rho se calcula como lambda / mu (ya que mu es por servidor y s=1)
    if lambda_val >= mu_val:
        rho_calculado = lambda_val / mu_val if mu_val > 0 else float('inf')
        return (f"Error (M/M/1): Sistema inestable o críticamente cargado (λ_norm={lambda_val:.3f} >= μ_norm={mu_val:.3f}; ρ = {rho_calculado:.3f}). "
                "Medidas de estado estable no aplican.")

    rho = lambda_val / mu_val
    
    L = lambda_val / (mu_val - lambda_val)
    Lq = (lambda_val**2) / (mu_val * (mu_val - lambda_val))
    W = 1 / (mu_val - lambda_val) # Tiempo en la unidad base (ej. horas)
    Wq = lambda_val / (mu_val * (mu_val - lambda_val)) # Tiempo en la unidad base (ej. horas)
    P0 = 1.0 - rho
    Ts_servicio = 1.0 / mu_val # Tiempo de servicio en la unidad base (ej. horas)

    resultados = {
        "lambda_normalizada_por_hora": lambda_val, # Asumiendo que la normalización es a horas
        "mu_normalizada_por_hora": mu_val,
        "rho_utilizacion": rho,
        "L_sistema_promedio": L,
        "Lq_cola_promedio": Lq,
        "W_sistema_promedio_horas": W,
        "Wq_cola_promedio_horas": Wq,
        "P0_sistema_vacio": P0,
        "Ts_servicio_promedio_horas": Ts_servicio
    }
    return resultados

def calcular_probabilidad_n_mm1(parametros_finales: dict, n: int) -> float | str:
    """
    Calcula la probabilidad de que haya exactamente 'n' clientes en un sistema M/M/1,
    utilizando tasas normalizadas. n debe ser un entero no negativo.
    """
    lambda_val = _get_lambda_eff(parametros_finales)
    mu_val = _get_mu_rate_eff(parametros_finales)

    if lambda_val is None: return "Error (Pn M/M/1): Lambda no determinada."
    if mu_val is None: return "Error (Pn M/M/1): Mu no determinada."
    if not (isinstance(n, int) and n >= 0): return "Error: 'n' debe ser un entero no negativo."

    if lambda_val > mu_val:
        return "Error (Pn M/M/1): Sistema inestable (λ > μ)."
    if math.isclose(lambda_val, mu_val):
        return "Error (Pn M/M/1): Sistema críticamente cargado (λ = μ)."

    rho = lambda_val / mu_val
    Pn = (1.0 - rho) * (rho**n)
    return Pn

def _check_mm1k(params: dict, num_servidores: int) -> tuple[bool, int | None]:
    if num_servidores == 1:
        es_finita, valor_k_num = _es_capacidad_finita_valida(params)
        if es_finita and valor_k_num is not None and valor_k_num >= 1: 
            return True, valor_k_num
    return False, None

def calcular_medidas_mm1k(parametros_finales: dict) -> dict | str:
    """
    Calcula las principales medidas de desempeño para un modelo de colas M/M/1/K.
    Utiliza tasas normalizadas (ej. por hora) obtenidas de _get_lambda_eff y _get_mu_rate_eff.
    K se extrae de parametros_finales["capacidad_sistema"]["valor"].

    Args:
        parametros_finales (dict): Diccionario consolidado de parámetros.

    Returns:
        dict: Diccionario con medidas de desempeño si los parámetros son válidos.
        str: Mensaje de error si hay problemas.
    """
    lambda_val = _get_lambda_eff(parametros_finales)
    mu_val = _get_mu_rate_eff(parametros_finales)
    
    k_info = parametros_finales.get("capacidad_sistema", {})
    K_capacity_raw = k_info.get("valor")

    if lambda_val is None:
        return "Error (M/M/1/K): Tasa de llegada (lambda) no pudo ser determinada o normalizada."
    if mu_val is None:
        return "Error (M/M/1/K): Tasa de servicio (mu) no pudo ser determinada o normalizada."
    
    if not (isinstance(K_capacity_raw, (int, float)) and K_capacity_raw >= 1):
        return f"Error (M/M/1/K): Capacidad del sistema K ('{K_capacity_raw}') debe ser un entero >= 1."
    K = int(K_capacity_raw)

    if mu_val == 0: # Evitar división por cero si mu_val es cero después de normalización
        return "Error (M/M/1/K): Tasa de servicio (mu) normalizada no puede ser cero."

    rho = lambda_val / mu_val
    P0 = 0.0
    L = 0.0

    if math.isclose(rho, 1.0): # Caso especial rho = 1
        if K + 1 == 0: # Evitar división por cero teórica, aunque K >= 1
            return "Error (M/M/1/K): K+1 es cero, inválido para rho=1."
        P0 = 1.0 / (float(K) + 1.0)
        L = float(K) / 2.0
    else: # Caso rho != 1
        denominador_P0 = (1.0 - (rho**(float(K) + 1.0)))
        if math.isclose(denominador_P0, 0.0):
             return f"Error (M/M/1/K): Imposible calcular P0 (1 - rho^(K+1) es cero) con K={K}, rho={rho:.4f}."
        P0 = (1.0 - rho) / denominador_P0
        
        # Fórmula para L cuando rho != 1
        # L = rho * (1 - (K + 1) * rho^K + K * rho^(K + 1)) / ((1 - rho) * (1 - rho^(K + 1)))
        numer_L = rho * (1.0 - (float(K) + 1.0) * (rho**K) + float(K) * (rho**(float(K) + 1.0)))
        denom_L = (1.0 - rho) * denominador_P0 # Reusar denominador_P0 (ya chequeado)
        # denom_L también podría ser cero si 1-rho es cero, pero ya manejamos rho=1.
        
        L = numer_L / denom_L
        
    # Pk (Probabilidad de K clientes en el sistema - sistema lleno)
    Pk = P0 * (rho**K)

    # Tasa de llegada efectiva (clientes que entran al sistema)
    lambda_efectiva = lambda_val * (1.0 - Pk)

    # Lq: Número promedio en la cola
    # Lq = L - (fracción de tiempo que el servidor está ocupado)
    # Fracción de tiempo servidor ocupado = lambda_efectiva / mu_val (para s=1) = 1 - P0
    Lq = L - (1.0 - P0)
    # Corregir pequeñas imprecisiones de flotantes si Lq es casi cero
    if Lq < 0 and math.isclose(Lq, 0.0):
        Lq = 0.0
    elif Lq < 0: # Si es significativamente negativo, indica un problema en L o P0
        print(f"ADVERTENCIA (M/M/1/K): Lq calculado negativo ({Lq:.4g}), L={L:.4g}, P0={P0:.4g}. Estableciendo Lq a 0.")
        Lq = 0.0 # O devolver un error/indicación

    # W y Wq (usando Little's Law con lambda_efectiva)
    W_sistema_horas = 0.0
    Wq_cola_horas = 0.0
    if lambda_efectiva > 1e-9: # Evitar división por cero si casi no entran clientes
        W_sistema_horas = L / lambda_efectiva
        Wq_cola_horas = Lq / lambda_efectiva
    elif math.isclose(L, 0.0): # Si L es 0 y lambda_efectiva es 0, los tiempos son 0
        pass # Ya están inicializados a 0.0
    # Si lambda_efectiva es 0 pero L > 0, W tendería a infinito (no debería pasar si Pk < 1 o lambda_val > 0)

    Ts_servicio_horas = 1.0 / mu_val # Tiempo de servicio promedio en horas

    resultados = {
        "lambda_original_oferta": lambda_val, # Tasa de oferta original (normalizada a horas)
        "mu_servicio_por_servidor": mu_val,   # Tasa de servicio (normalizada a horas)
        "K_capacidad_sistema": K,
        "rho_factor_utilizacion_ofrecido": rho,
        "P0_sistema_vacio": P0,
        "Pk_sistema_lleno_bloqueo": Pk,
        "lambda_efectiva_entradas": lambda_efectiva, # Tasa efectiva de clientes que entran
        "L_sistema_promedio": L,
        "Lq_cola_promedio": Lq,
        "W_sistema_promedio_horas": W_sistema_horas,
        "Wq_cola_promedio_horas": Wq_cola_horas,
        "Ts_servicio_promedio_horas": Ts_servicio_horas
    }
    return resultados

def calcular_probabilidad_n_mm1k(parametros_finales: dict, n: int) -> float | str:
    """
    Calcula Pn para M/M/1/K, usando tasas normalizadas.
    n debe ser un entero no negativo y n <= K.
    """
    lambda_val = _get_lambda_eff(parametros_finales)
    mu_val = _get_mu_rate_eff(parametros_finales)
    k_info = parametros_finales.get("capacidad_sistema", {})
    K_capacity_raw = k_info.get("valor")

    if lambda_val is None: return "Error (Pn M/M/1/K): Lambda no determinada."
    if mu_val is None: return "Error (Pn M/M/1/K): Mu no determinada."
    
    if not (isinstance(K_capacity_raw, (int, float)) and K_capacity_raw >= 1):
        return f"Error (Pn M/M/1/K): Capacidad K ('{K_capacity_raw}') debe ser un entero >= 1."
    K = int(K_capacity_raw)
    
    if not (isinstance(n, int) and 0 <= n <= K): # n debe estar dentro de la capacidad del sistema
        return f"Error (Pn M/M/1/K): 'n' ({n}) debe ser un entero entre 0 y K ({K})."
    
    if mu_val == 0: return "Error (Pn M/M/1/K): Tasa de servicio (mu) no puede ser cero."

    rho = lambda_val / mu_val
    P0 = 0.0

    if math.isclose(rho, 1.0): # Caso rho = 1
        if K + 1 == 0: return "Error (Pn M/M/1/K): K+1 es cero."
        P0 = 1.0 / (float(K) + 1.0)
    else: # Caso rho != 1
        denominador_P0 = (1.0 - (rho**(float(K) + 1.0)))
        if math.isclose(denominador_P0, 0.0):
            return f"Error (Pn M/M/1/K): Imposible calcular P0 (denominador es cero) para K={K}, rho={rho:.4f}."
        P0 = (1.0 - rho) / denominador_P0
        
    Pn = P0 * (rho**n)
    return Pn

def _check_mms(params: dict, num_servidores: int) -> bool: 
    return num_servidores > 1 and _es_capacidad_infinita(params)

def _calcular_p0_mms(lambda_val: float, mu_val: float, s: int) -> float | None:
    """
    Calcula P0 (probabilidad de 0 clientes en el sistema) para un modelo M/M/s.
    Requiere lambda_val < s * mu_val para la convergencia de la suma.
    """
    if lambda_val == 0: # Si no hay llegadas, el sistema siempre está vacío.
        return 1.0
    if mu_val <= 0 or s <= 0: # Tasas de servicio o servidores no válidos
        return None

    # rho_s es la utilización por servidor: lambda / (s * mu)
    # lambda_mu_ratio es a menudo 'a' o 'r' en los textos: lambda / mu
    # (lambda/mu) = s * rho_s
    
    rho_s = lambda_val / (float(s) * mu_val)
    if rho_s >= 1.0 and not math.isclose(rho_s, 1.0): # Inestable si rho_s > 1
        print(f"ADVERTENCIA (P0 M/M/s): Sistema inestable (rho_s = {rho_s:.4f} >= 1). P0 teóricamente es 0.")
        return 0.0 # O None, ya que las fórmulas de estado estable no aplican bien
    if math.isclose(rho_s, 1.0): # Críticamente cargado, la suma para P0 diverge
        print(f"ADVERTENCIA (P0 M/M/s): Sistema críticamente cargado (rho_s = {rho_s:.4f} ≈ 1). P0 no se puede calcular con esta fórmula (tiende a 0).")
        return None


    lambda_mu_ratio = lambda_val / mu_val

    sum_part_1 = 0.0
    for n_i in range(s):  # Suma de n=0 hasta s-1
        try:
            term = (lambda_mu_ratio ** n_i) / math.factorial(n_i)
            sum_part_1 += term
        except OverflowError:
            print(f"ERROR (P0 M/M/s): Overflow en sum_part_1 para n={n_i}. lambda/mu ({lambda_mu_ratio}) podría ser muy grande.")
            return None

    try:
        term_part_2_num = lambda_mu_ratio ** s
        term_part_2_den = math.factorial(s) * (1.0 - rho_s)
    except OverflowError:
        print(f"ERROR (P0 M/M/s): Overflow en term_part_2. lambda/mu ({lambda_mu_ratio}) o s ({s}) podrían ser muy grandes.")
        return None
    
    if math.isclose(term_part_2_den, 0.0): # Debería ser capturado por rho_s >= 1
        print(f"ERROR (P0 M/M/s): Denominador del segundo término es cero (rho_s ({rho_s:.4f}) ≈ 1).")
        return None
        
    sum_part_2 = term_part_2_num / term_part_2_den
    
    denominator_p0 = sum_part_1 + sum_part_2
    if math.isinf(denominator_p0) or math.isclose(denominator_p0, 0.0):
        print(f"ERROR (P0 M/M/s): Denominador de P0 es {denominator_p0}. Indica problema numérico o inestabilidad.")
        return None
        
    P0 = 1.0 / denominator_p0
    return P0

def calcular_medidas_mms(parametros_finales: dict) -> dict | str:
    """
    Calcula las principales medidas de desempeño para un modelo de colas M/M/s.
    Utiliza tasas normalizadas (ej. por hora).
    """
    lambda_val = _get_lambda_eff(parametros_finales)
    mu_val = _get_mu_rate_eff(parametros_finales) # Tasa de servicio POR SERVIDOR
    num_s = _get_numero_servidores(parametros_finales)

    if lambda_val is None: return "Error (M/M/s): Lambda no determinada o inválida."
    if mu_val is None: return "Error (M/M/s): Mu no determinada o inválida."
    if num_s is None: return "Error (M/M/s): Número de servidores (s) inválido."

    if mu_val == 0: return "Error (M/M/s): Tasa de servicio (mu) no puede ser cero."

    # Condición de estabilidad: lambda < s * mu  (o rho_s < 1)
    if lambda_val >= (float(num_s) * mu_val) and not math.isclose(lambda_val, (float(num_s) * mu_val)):
        rho_s_calc = lambda_val / (float(num_s) * mu_val)
        return (f"Error (M/M/s): Sistema inestable (λ >= s*μ; ρ_s = {rho_s_calc:.3f} >= 1). "
                "Medidas de estado estable no aplican.")
    
    # Si es críticamente cargado (lambda = s*mu), P0 no se puede calcular con la fórmula estándar.
    if math.isclose(lambda_val, (float(num_s) * mu_val)):
        return (f"Error (M/M/s): Sistema críticamente cargado (λ ≈ s*μ; ρ_s ≈ 1). "
                "P0 y otras medidas no se pueden calcular con las fórmulas estándar de estado estable.")

    rho_s = lambda_val / (float(num_s) * mu_val) # Utilización por servidor
    lambda_mu_ratio = lambda_val / mu_val       # 'a' en algunas fórmulas

    P0 = _calcular_p0_mms(lambda_val, mu_val, num_s)
    if P0 is None or not (0 <= P0 <= 1): # Chequeo de P0
        return f"Error (M/M/s): No se pudo calcular P0 válidamente (P0={P0}). Verifique parámetros o estabilidad."

    # Pw: Probabilidad de que un cliente que llega tenga que esperar (Erlang C)
    # Pw = [ ( (lambda/mu)^s / s! ) * (1 / (1 - rho_s)) ] * P0
    try:
        pw_term1_num = lambda_mu_ratio ** num_s
        pw_term1_den = math.factorial(num_s)
        pw_term2 = 1.0 / (1.0 - rho_s) # rho_s < 1 ya fue chequeado
    except OverflowError:
        return f"Error (M/M/s): Overflow calculando Pw. lambda/mu o s muy grandes."

    Pw = (pw_term1_num / pw_term1_den) * pw_term2 * P0
    # Ajuste por precisión si Pw es ligeramente > 1 o < 0
    if Pw > 1.0 and math.isclose(Pw, 1.0): Pw = 1.0
    elif Pw < 0.0 and math.isclose(Pw, 0.0): Pw = 0.0
    elif not (0 <= Pw <= 1.0):
         print(f"ADVERTENCIA (M/M/s): Pw calculado ({Pw:.4g}) fuera de [0,1]. P0={P0:.3g}, rho_s={rho_s:.3g}")


    # Lq: Número promedio de clientes en la cola
    # Lq = Pw * rho_s / (1 - rho_s)
    Lq = (Pw * rho_s) / (1.0 - rho_s)
    
    # L: Número promedio de clientes en el sistema
    L = Lq + lambda_mu_ratio # L = Lq + lambda/mu
    
    # Wq: Tiempo promedio de un cliente en la cola (en horas)
    Wq_horas = Lq / lambda_val if lambda_val > 0 else 0.0
    
    # W: Tiempo promedio de un cliente en el sistema (en horas)
    W_horas = L / lambda_val if lambda_val > 0 else 0.0
    # O W_horas = Wq_horas + (1.0 / mu_val)

    Ts_servicio_horas = 1.0 / mu_val

    resultados = {
        "lambda_normalizada_hora": lambda_val,
        "mu_normalizada_hora_por_servidor": mu_val,
        "s_servidores": num_s,
        "rho_s_utilizacion_por_servidor": rho_s, # ρ_s = λ / (sμ)
        "a_trafico_ofrecido_dividido_mu": lambda_mu_ratio, # a = λ/μ
        "P0_sistema_vacio": P0,
        "Pw_probabilidad_espera": Pw,
        "L_sistema_promedio": L,
        "Lq_cola_promedio": Lq,
        "W_sistema_promedio_horas": W_horas,
        "Wq_cola_promedio_horas": Wq_horas,
        "Ts_servicio_promedio_horas": Ts_servicio_horas
    }
    return resultados

def calcular_probabilidad_n_mms(parametros_finales: dict, n: int) -> float | str:
    """
    Calcula Pn para M/M/s, usando tasas normalizadas.
    n debe ser un entero no negativo.
    """
    lambda_val = _get_lambda_eff(parametros_finales)
    mu_val = _get_mu_rate_eff(parametros_finales)
    num_s = _get_numero_servidores(parametros_finales)

    if lambda_val is None: return "Error (Pn M/M/s): Lambda no determinada."
    if mu_val is None: return "Error (Pn M/M/s): Mu no determinada."
    if num_s is None: return "Error (Pn M/M/s): Número de servidores (s) no determinado."
    if not (isinstance(n, int) and n >= 0): return "Error (Pn M/M/s): 'n' debe ser entero no negativo."
    if mu_val == 0: return "Error (Pn M/M/s): Tasa de servicio (mu) no puede ser cero."

    if lambda_val >= (float(num_s) * mu_val) and not math.isclose(lambda_val, (float(num_s) * mu_val)):
        return "Error (Pn M/M/s): Sistema inestable (λ >= s*μ)."
    if math.isclose(lambda_val, (float(num_s) * mu_val)):
        return "Error (Pn M/M/s): Sistema críticamente cargado (λ ≈ s*μ)."

    P0 = _calcular_p0_mms(lambda_val, mu_val, num_s)
    if P0 is None: return "Error (Pn M/M/s): No se pudo calcular P0."

    lambda_mu_ratio = lambda_val / mu_val
    Pn = 0.0

    try:
        if 0 <= n < num_s:
            Pn = ((lambda_mu_ratio**n) / math.factorial(n)) * P0
        elif n >= num_s:
            # Pn = ( (lambda/mu)^s / s! ) * (lambda / (s*mu))^(n-s) * P0
            # Pn = ( (lambda/mu)^s / s! ) * rho_s^(n-s) * P0
            term1_num = lambda_mu_ratio**num_s
            term1_den = math.factorial(num_s)
            rho_s = lambda_val / (float(num_s) * mu_val)
            term2 = rho_s**(n - num_s)
            Pn = (term1_num / term1_den) * term2 * P0
    except OverflowError:
        return f"Error (Pn M/M/s): Overflow calculando Pn para n={n}. Valores muy grandes."
        
    return Pn

def _check_mmsk(params: dict, num_servidores: int) -> tuple[bool, int | None]:
    if num_servidores > 1:
        es_finita, valor_k_num = _es_capacidad_finita_valida(params)
        if es_finita and valor_k_num is not None and valor_k_num >= num_servidores: 
            return True, valor_k_num
    return False, None

def _calcular_p0_mmsk(lambda_val: float, mu_val: float, s: int, K: int) -> float | None:
    """
    Calcula P0 (probabilidad de 0 clientes) para un modelo M/M/s/K.
    """
    if lambda_val == 0: return 1.0 # No hay llegadas, sistema siempre vacío
    if mu_val <= 0 or s <= 0 or K < s: # K debe ser al menos s
        print(f"ERROR (P0 M/M/s/K): Parámetros inválidos mu={mu_val}, s={s}, K={K}")
        return None

    a = lambda_val / mu_val  # Relación lambda/mu
    
    sum_part1 = 0.0
    for n_i in range(s):  # Suma de n=0 hasta s-1
        try:
            term = (a ** n_i) / math.factorial(n_i)
            sum_part1 += term
        except OverflowError:
            print(f"ERROR (P0 M/M/s/K): Overflow en sum_part1 para n={n_i}. 'a' ({a}) podría ser muy grande.")
            return None

    sum_part2 = 0.0
    try:
        factor_comun_part2 = (a ** s) / math.factorial(s)
    except OverflowError:
        print(f"ERROR (P0 M/M/s/K): Overflow en factor_comun_part2. 'a' ({a}) o s ({s}) podrían ser muy grandes.")
        return None

    rho_s = lambda_val / (float(s) * mu_val) # Utilización si todos los servidores estuvieran siempre ocupados

    if math.isclose(rho_s, 1.0): # Caso especial donde lambda/(s*mu) = 1
        sum_geometrica_part2 = float(K - s + 1)
    else: # lambda/(s*mu) != 1
        if math.isclose(1.0 - rho_s, 0.0): # Debería ser cubierto por math.isclose(rho_s, 1.0)
            print(f"ERROR (P0 M/M/s/K): Denominador (1-rho_s) es cero en suma geométrica, rho_s={rho_s}")
            return None
        try:
            # Suma de rho_s^j para j desde 0 hasta K-s
            sum_geometrica_part2 = (1.0 - rho_s**(float(K - s + 1))) / (1.0 - rho_s)
        except OverflowError:
            print(f"ERROR (P0 M/M/s/K): Overflow en suma geométrica. rho_s ({rho_s}) o K-s+1 ({K-s+1}) muy grandes.")
            return None
            
    sum_part2 = factor_comun_part2 * sum_geometrica_part2
    
    denominador_p0 = sum_part1 + sum_part2
    if math.isinf(denominador_p0) or math.isclose(denominador_p0, 0.0):
        print(f"ERROR (P0 M/M/s/K): Denominador de P0 es {denominador_p0}. Indica problema.")
        return None
        
    P0 = 1.0 / denominador_p0
    return P0

def calcular_medidas_mmsk(parametros_finales: dict) -> dict | str:
    """
    Calcula las principales medidas de desempeño para un modelo de colas M/M/s/K.
    """
    lambda_val = _get_lambda_eff(parametros_finales)
    mu_val = _get_mu_rate_eff(parametros_finales) # Tasa de servicio POR SERVIDOR
    num_s = _get_numero_servidores(parametros_finales)
    
    k_info = parametros_finales.get("capacidad_sistema", {})
    K_capacity_raw = k_info.get("valor")

    if lambda_val is None: return "Error (M/M/s/K): Lambda no determinada o inválida."
    if mu_val is None: return "Error (M/M/s/K): Mu no determinada o inválida."
    if num_s is None: return "Error (M/M/s/K): Número de servidores (s) no determinado o inválido."
    
    if not (isinstance(K_capacity_raw, (int, float)) and K_capacity_raw >= num_s):
        return f"Error (M/M/s/K): Capacidad K ('{K_capacity_raw}') debe ser un entero >= s ({num_s})."
    K = int(K_capacity_raw)

    if mu_val == 0: return "Error (M/M/s/K): Tasa de servicio (mu) no puede ser cero."

    a = lambda_val / mu_val # lambda/mu
    rho_s = lambda_val / (float(num_s) * mu_val) # rho_s = a / s (utilización si el sistema fuera infinito y estable)

    P0 = _calcular_p0_mmsk(lambda_val, mu_val, num_s, K)
    if P0 is None or not (0 <= P0 <= 1.00001): # Permitir una pequeña imprecisión
        return f"Error (M/M/s/K): No se pudo calcular P0 válidamente (P0={P0}). Verifique parámetros."
    if P0 > 1.0 : P0 = 1.0 # Cap P0 at 1

    # Pk (Probabilidad de K clientes en el sistema - sistema lleno)
    Pk = 0.0
    try:
        if 0 <= K < num_s: # Si K < s, la fórmula es como M/M/K/K (todos son servidores)
            Pk = ((a**K) / math.factorial(K)) * P0
        elif K >= num_s: # La fórmula estándar para M/M/s/K con n=K
            Pk = (((a**num_s) / math.factorial(num_s)) * (rho_s**(K - num_s))) * P0
    except OverflowError:
        return "Error (M/M/s/K): Overflow al calcular Pk. Valores muy grandes."

    if not (0 <= Pk <= 1.00001): # Permitir una pequeña imprecisión
        print(f"ADVERTENCIA (M/M/s/K): Pk calculado ({Pk:.4g}) fuera de [0,1]. Ajustando si es cercano.")
        if Pk > 1.0 and math.isclose(Pk, 1.0): Pk = 1.0
        elif Pk < 0.0 and math.isclose(Pk, 0.0): Pk = 0.0
        # Si está significativamente fuera, podría indicar un problema con P0 o los parámetros.

    # Tasa de llegada efectiva
    lambda_efectiva = lambda_val * (1.0 - Pk)

    # Lq: Número promedio en la cola
    Lq = 0.0
    if math.isclose(rho_s, 1.0): # rho_s = lambda / (s*mu) = 1
        try:
            factor_comun = (a**num_s) / math.factorial(num_s)
            Lq = P0 * factor_comun * ( (float(K - num_s) * (K - num_s + 1.0)) / 2.0 )
        except OverflowError: return "Error (M/M/s/K): Overflow en Lq para rho_s=1."
    else: # rho_s != 1
        try:
            factor_comun = (a**num_s) / math.factorial(num_s) # P0 * (a^s / s!)
            # Suma para Lq: rho_s * (1 - rho_s^(K-s) - (K-s) * rho_s^(K-s) * (1-rho_s) ) / (1-rho_s)^2
            # O también: sum_{j=1}^{K-s} j * rho_s^j
            m = K - num_s # Longitud máxima de la cola más allá de s
            if m > 0 : # Solo hay cola si K > s
                sum_jqj = rho_s * (1.0 - (m + 1.0) * (rho_s**m) + m * (rho_s**(m + 1.0))) / ((1.0 - rho_s)**2)
                Lq = P0 * factor_comun * sum_jqj
            else: # K=s, no puede haber cola (Lq=0)
                Lq = 0.0
        except OverflowError: return "Error (M/M/s/K): Overflow en Lq para rho_s!=1."
        except ZeroDivisionError: return "Error (M/M/s/K): División por cero en Lq para rho_s!=1 (inesperado)."

    if Lq < 0 and math.isclose(Lq, 0.0): Lq = 0.0
    elif Lq < 0: print(f"ADVERTENCIA (M/M/s/K): Lq negativo ({Lq:.4g}). Ajustando a 0."); Lq = 0.0


    # L: Número promedio en el sistema L = Lq + lambda_efectiva / mu_val
    L = Lq + (lambda_efectiva / mu_val if mu_val > 0 else 0)

    # W y Wq (usando Little's Law con lambda_efectiva)
    W_sistema_horas = L / lambda_efectiva if lambda_efectiva > 1e-9 else 0.0
    Wq_cola_horas = Lq / lambda_efectiva if lambda_efectiva > 1e-9 else 0.0
    
    Ts_servicio_horas = 1.0 / mu_val

    resultados = {
        "lambda_original_oferta": lambda_val,
        "mu_servicio_por_servidor": mu_val,
        "s_servidores": num_s,
        "K_capacidad_sistema": K,
        "a_lambda_sobre_mu": a,
        "rho_s_trafico_por_servidor": rho_s, # ρ_s = λ / (sμ)
        "P0_sistema_vacio": P0,
        "Pk_sistema_lleno_bloqueo": Pk,
        "lambda_efectiva_entradas": lambda_efectiva,
        "L_sistema_promedio": L,
        "Lq_cola_promedio": Lq,
        "W_sistema_promedio_horas": W_sistema_horas,
        "Wq_cola_promedio_horas": Wq_cola_horas,
        "Ts_servicio_promedio_horas": Ts_servicio_horas
    }
    return resultados

def calcular_probabilidad_n_mmsk(parametros_finales: dict, n: int) -> float | str:
    """
    Calcula Pn para M/M/s/K, usando tasas normalizadas.
    n debe ser un entero no negativo y n <= K.
    """
    lambda_val = _get_lambda_eff(parametros_finales)
    mu_val = _get_mu_rate_eff(parametros_finales)
    num_s = _get_numero_servidores(parametros_finales)
    k_info = parametros_finales.get("capacidad_sistema", {})
    K_capacity_raw = k_info.get("valor")

    if lambda_val is None: return "Error (Pn M/M/s/K): Lambda no determinada."
    if mu_val is None: return "Error (Pn M/M/s/K): Mu no determinada."
    if num_s is None: return "Error (Pn M/M/s/K): s no determinado."
    
    if not (isinstance(K_capacity_raw, (int, float)) and K_capacity_raw >= num_s):
        return f"Error (Pn M/M/s/K): Capacidad K ('{K_capacity_raw}') debe ser entero >= s ({num_s})."
    K = int(K_capacity_raw)
    
    if not (isinstance(n, int) and 0 <= n <= K):
        return f"Error (Pn M/M/s/K): 'n' ({n}) debe ser entero entre 0 y K ({K})."
    if mu_val == 0: return "Error (Pn M/M/s/K): Tasa de servicio (mu) no puede ser cero."

    P0 = _calcular_p0_mmsk(lambda_val, mu_val, num_s, K)
    if P0 is None: return "Error (Pn M/M/s/K): No se pudo calcular P0."

    a = lambda_val / mu_val # lambda/mu
    Pn = 0.0
    try:
        if 0 <= n < num_s:
            Pn = ((a**n) / math.factorial(n)) * P0
        elif num_s <= n <= K:
            rho_s = lambda_val / (float(num_s) * mu_val)
            # Pn = ( (a^s / s!) * rho_s^(n-s) ) * P0
            # O, Pn = (a^n / (s! * s^(n-s))) * P0
            Pn = ((a**n) / (math.factorial(num_s) * (float(num_s)**(n - num_s)))) * P0
    except OverflowError:
        return f"Error (Pn M/M/s/K): Overflow calculando Pn para n={n}. Valores muy grandes."
        
    return Pn

def identificar_modelo_cola(parametros_finales: dict) -> str:
    if not isinstance(parametros_finales, dict):
        return False, "Error: Datos de entrada no son un diccionario."

    lambda_efectiva = _get_lambda_eff(parametros_finales)
    mu_efectiva_por_servidor = _get_mu_rate_eff(parametros_finales)
    num_s = _get_numero_servidores(parametros_finales)
    
    # Validación base ahora verifica si se pudieron calcular las tasas normalizadas y num_s
    if not _validar_parametros_base_para_rho(lambda_efectiva, mu_efectiva_por_servidor, num_s):
        return False, "Parámetros base (llegadas, servicio o servidores) inválidos o faltantes para identificación."

    modelo_base = None
    es_modelo_con_k_finito = False

    if num_s == 1:
        es_mm1k_valido, k_val = _check_mm1k(parametros_finales, num_s)
        if es_mm1k_valido: 
            modelo_base = "M/M/1/K"
            es_modelo_con_k_finito = True
        elif _check_mm1(parametros_finales, num_s): 
            modelo_base = "M/M/1"
    elif num_s > 1:
        es_mmsk_valido, k_val = _check_mmsk(parametros_finales, num_s)
        if es_mmsk_valido: 
            modelo_base = "M/M/s/K"
            es_modelo_con_k_finito = True
        elif _check_mms(parametros_finales, num_s): 
            modelo_base = "M/M/s"
            
    if not modelo_base:
        return False, "Modelo no identificado (no es M/M/1, M/M/1/K, M/M/s, o M/M/s/K)."

    if es_modelo_con_k_finito:
        # lambda_efectiva, mu_efectiva_por_servidor, num_s están validados y son numéricos aquí
        if mu_efectiva_por_servidor == 0 : # Evitar división por cero
             return True, f"{modelo_base} (ρ no calculable: tasa de servicio es cero)"
        
        rho = lambda_efectiva / (float(num_s) * mu_efectiva_por_servidor)
        
        # Usar math.isclose para comparar flotantes
        if math.isclose(rho, 1.0):
            return True, f"{modelo_base} (ρ = 1)"
        else:
            rho_str = f"{rho:.3f}".rstrip('0').rstrip('.')
            return True, f"{modelo_base} (ρ ≠ 1)"
    else:
        return True, modelo_base

if __name__ == '__main__':
    # ... (pruebas para M/M/1 y M/M/s como antes) ...
    print("\n--- Calculadora para Modelo M/M/s/K ---")

    params_mmsk_1 = {
        "tasa_llegada": {"valor": 10, "unidades": "clientes/hora"}, # lambda = 10
        "tiempo_servicio_por_servidor": {"valor": 10, "unidades": "minutos"}, # mu_r = 6 clientes/hora/servidor
        "cantidad_servidores": {"valor": 2}, # s = 2
        "capacidad_sistema": {"valor": 5} # K = 5
    } # lambda_eff = 10, mu_eff = 6, s = 2, K=5. a = 10/6 = 1.666. rho_s = (10/6)/2 = 10/12 = 0.8333
    print(f"\nEjemplo M/M/s/K (s=2, K=5, ρ_s<1): {params_mmsk_1}")
    medidas_mmsk_1 = calcular_medidas_mmsk(params_mmsk_1)
    if isinstance(medidas_mmsk_1, dict):
        for clave, valor in medidas_mmsk_1.items(): print(f"  {clave:<35}: {valor:.4f}")
    else: print(f"  Error: {medidas_mmsk_1}")

    print("\n  Probabilidades Pn (M/M/s/K):")
    if isinstance(medidas_mmsk_1, dict):
        K_val = medidas_mmsk_1.get("K_capacidad_sistema")
        if K_val is not None:
            for i in range(int(K_val) + 1): 
                prob_n = calcular_probabilidad_n_mmsk(params_mmsk_1, i)
                if isinstance(prob_n, str): print(f"  P({i}): {prob_n}")
                else: print(f"  P({i}): {prob_n:.4f}")
    
    params_mmsk_rho_s_eq_1 = {
        "tasa_llegada": {"valor": 12, "unidades": "clientes/hora"}, # lambda = 12
        "tiempo_servicio_por_servidor": {"valor": 10, "unidades": "minutos"}, # mu_r = 6
        "cantidad_servidores": {"valor": 2}, # s = 2
        "capacidad_sistema": {"valor": 4} # K=4
    } # lambda = 12, s*mu = 12. rho_s = 1
    print(f"\nEjemplo M/M/s/K (s=2, K=4, ρ_s=1): {params_mmsk_rho_s_eq_1}")
    medidas_mmsk_rho_s_1 = calcular_medidas_mmsk(params_mmsk_rho_s_eq_1)
    if isinstance(medidas_mmsk_rho_s_1, dict):
        for clave, valor in medidas_mmsk_rho_s_1.items(): print(f"  {clave:<35}: {valor:.4f}")
    else: print(f"  Error: {medidas_mmsk_rho_s_1}")

    print("\n  Probabilidades Pn (M/M/s/K, ρ_s=1):")
    if isinstance(medidas_mmsk_rho_s_1, dict):
        K_val = medidas_mmsk_rho_s_1.get("K_capacidad_sistema")
        if K_val is not None:
            for i in range(int(K_val) + 1):
                prob_n = calcular_probabilidad_n_mmsk(params_mmsk_rho_s_eq_1, i)
                if isinstance(prob_n, str): print(f"  P({i}): {prob_n}")
                else: print(f"  P({i}): {prob_n:.4f}")