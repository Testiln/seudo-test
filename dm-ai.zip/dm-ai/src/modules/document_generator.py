import os
import re
from docx import Document

def guardar_en_word(texto, nombre_archivo_word, PROJECT_ROOT_DIR):
    try:
        docs_dir_abs = os.path.join(PROJECT_ROOT_DIR, "docs")
        if not os.path.exists(docs_dir_abs):
            os.makedirs(docs_dir_abs, exist_ok=True)
            print(f"Dir '{docs_dir_abs}' creado.")
        ruta_word = os.path.join(docs_dir_abs, nombre_archivo_word)
        documento = Document()
        match_enunciado = re.search(r"#(\d+)", nombre_archivo_word)
        titulo_enunciado = f"Enunciado {match_enunciado.group(1)}" if match_enunciado else "Enunciado procesado"
        documento.add_heading(titulo_enunciado, level=1)
        documento.add_paragraph(texto if texto else "No se pudo transcribir texto de la imagen.")
        documento.save(ruta_word)
        print(f"Texto guardado en: {ruta_word}")
        return True
    except Exception as e: 
        print(f"Error al guardar Word '{nombre_archivo_word}': {e}")
        return False

def _primer_supuesto(doc, tasa_llegada, tiempo_entre_llegadas):
    doc.add_heading("Supuesto 1", level=1)
    doc.add_paragraph("✓ Enunciado 1.")
    if tasa_llegada.get("valor") is not None:
        distr = tasa_llegada.get("distribucion")
        doc.add_paragraph(f"✓ La distribución de probabilidad de la tasa es \"{distr if distr is not None else "Poisson"}\".")
        doc.add_paragraph(f"✓ La tasa media de llegada es de \"{tasa_llegada.get("valor")}\".")
        doc.add_paragraph(f"✓ Las unidades son \"{tasa_llegada.get("unidades")}\".")
        doc.add_paragraph(f"✓ Texto del enunciado: \"{tasa_llegada.get("fragmento_texto")}\".")
        return True
    elif tiempo_entre_llegadas.get("valor") is not None:
        doc.add_paragraph(f"✓ La distribución de probabilidad del tiempo es \"{tiempo_entre_llegadas.get("distribucion")}\".")
        doc.add_paragraph(f"✓ El tiempo promedio entre llegadas es de \"{tiempo_entre_llegadas.get("valor")}\".")
        doc.add_paragraph(f"✓ Las unidades son \"{tiempo_entre_llegadas.get("unidades")}\".")
        doc.add_paragraph(f"✓ Texto del enunciado: \"{tiempo_entre_llegadas.get("fragmento_texto")}\".")
        return True
    else:
        doc.add_paragraph("No se pudo determinar la tasa media de llegada o el tiempo promedio entre llegadas.")
        return False
    
def _segundo_supuesto(doc, tasa_servicio_por_servidor, tiempo_servicio_por_servidor):
    doc.add_heading("Supuesto 2", level=1)
    doc.add_paragraph("✓ Enunciado 1.")
    if tasa_servicio_por_servidor.get("valor") is not None:
        doc.add_paragraph(f"✓ La distribución de probabilidad de la tasa es \"{tasa_servicio_por_servidor.get("distribucion")}\".")
        doc.add_paragraph(f"✓ La tasa media de servicio es de \"{tasa_servicio_por_servidor.get("valor")}\".")
        doc.add_paragraph(f"✓ Las unidades son \"{tasa_servicio_por_servidor.get("unidades")}\".")
        doc.add_paragraph(f"✓ Texto del enunciado: \"{tasa_servicio_por_servidor.get("fragmento_texto")}\".")
        return True
    elif tiempo_servicio_por_servidor.get("valor") is not None:
        doc.add_paragraph(f"✓ La distribución de probabilidad del tiempo es \"{tiempo_servicio_por_servidor.get("distribucion")}\".")
        doc.add_paragraph(f"✓ El tiempo promedio de servicio es de \"{tiempo_servicio_por_servidor.get("valor")}\".")
        doc.add_paragraph(f"✓ Las unidades son \"{tiempo_servicio_por_servidor.get("unidades")}\".")
        doc.add_paragraph(f"✓ Texto del enunciado: \"{tiempo_servicio_por_servidor.get("fragmento_texto")}\".")
        return True
    else:
        doc.add_paragraph("No se pudo determinar la tasa media de servicio o el tiempo promedio de servicio.")
        return False
    
def _tercer_supuesto(doc, esPrimerSupuesto, esSegundoSupuesto):
    if esPrimerSupuesto and esSegundoSupuesto:
        doc.add_heading("Supuesto 3", level=1)
        doc.add_paragraph("✓ Enunciado 1.")
        doc.add_paragraph("✓ La variable aleatoria del supuesto 1 (el tiempo que falta hasta el próximo nacimiento) y la variable aleatoria del supuesto 2 (el tiempo que falta hasta la siguiente muerte) son mutuamente independientes. La siguiente transición del estado del proceso es")
        doc.add_paragraph("n → n + 1 (un solo nacimiento)")
        doc.add_paragraph("o")
        doc.add_paragraph("n → n - 1 (una sola muerte),")
        doc.add_paragraph("lo que depende de cuál de las dos variables es más pequeña.")
        return True
    return False

def _cuarto_supuesto(doc, esTercerSupuesto):
    if esTercerSupuesto:
        doc.add_heading("Supuesto 4", level=1)
        doc.add_paragraph("✓ Enunciado 1.")
        doc.add_paragraph("✓ Se procederá cuando el sistema haya alcanzado la condición de estado estable (en caso de que pueda alcanzarla). Es decir, la tasa media a la que el proceso entra al estado n es igual a la tasa media a la que el proceso sale del estado n.")
        return True
    return False

def _quinto_supuesto(doc, cantidad_servidores):
    doc.add_heading("Supuesto 5", level=1)
    doc.add_paragraph("✓ Enunciado 1.")
    if cantidad_servidores.get("valor") is not None:
        doc.add_paragraph(f"✓ El número de servidores en paralelo es \"{cantidad_servidores.get("valor")}\".")
        doc.add_paragraph(f"✓ Texto del enunciado: \"{cantidad_servidores.get("fragmento_texto")}\".")
        return True
    doc.add_paragraph(f"No se pudo determinar el número de servidores en paralelo.")
    return False

def _sexto_supuesto(doc, capacidad_sistema):
    if not isinstance(capacidad_sistema.get("valor"), str):
        doc.add_heading("Supuesto 6 capacidad finita", level=1)
        doc.add_paragraph("✓ Enunciado 1.")
        doc.add_paragraph(f"✓ La capacidad del sistema es de \"{capacidad_sistema.get("valor")}\".")
        doc.add_paragraph(f"✓ Texto del enunciado: \"{capacidad_sistema.get("fragmento_texto")}\".")
        return True
    return False

def _poblacion_finita(doc, poblacion=None):
    if poblacion is not None:
        doc.add_heading("Población Finita", level=1)
        doc.add_paragraph(f"✓ Enunciado 1.")
        doc.add_paragraph("✓ Es un tema más avanzado que no podrá solucionarse con este programa.")
        doc.add_paragraph(f"✓ Texto del enunciado: \"{poblacion.get("fragmento_texto")}\".")
        return True
    return False

def _disciplina_cola(doc, disciplina_cola):
    if disciplina_cola.get("valor") is not None:
        doc.add_heading("Disciplina de atención", level=1)
        doc.add_paragraph(f"✓ Enunciado 1.")
        doc.add_paragraph(f"✓ La disciplina del sistema es de “{disciplina_cola.get("valor")}”.")
        doc.add_paragraph(f"✓ Texto del enunciado: “{disciplina_cola.get("fragmento_texto")}”.")

def generar_doc_dos(ai_response_params, nombre_archivo_word, project_root_dir): # Cambié ai_response a ai_response_params para claridad
    """
    Genera un documento de Word con los supuestos basados en los parámetros de la IA.

    Args:
        ai_response_params (dict): El diccionario que contiene la clave "parametros_extraidos"
                                   y dentro los parámetros como "tasa_llegada", etc.
                                   O directamente el diccionario de parámetros si ya está extraído.
        nombre_archivo_word (str): El nombre del archivo .docx a crear.
        project_root_dir (str): La ruta al directorio raíz del proyecto.
    """
    try:
        doc = Document() # Crear el documento UNA SOLA VEZ al inicio

        # Extraer el diccionario de parámetros si ai_response_params es la respuesta completa de la IA
        # Si ya es el diccionario de parámetros, esto no hará daño o se puede ajustar.
        parametros = ai_response_params if isinstance(ai_response_params.get("tasa_llegada"), dict) else ai_response_params.get("parametros_extraidos", {})

        if not parametros: # Si después de intentar obtener los parámetros, sigue vacío
            print(f"Error en generar_doc_dos: No se encontraron 'parametros_extraidos' en la respuesta de la IA o el diccionario de parámetros está vacío.")
            # Podrías querer guardar un doc vacío con un mensaje de error o simplemente retornar False
            doc.add_paragraph("Error: No se pudieron obtener los parámetros para generar los supuestos.")
            # ... (código para guardar este doc de error si se desea) ...
            return False

        # Obtener cada parámetro individualmente, proveyendo un dict vacío como default
        # para evitar errores si la clave principal no existe en 'parametros'
        tasa_llegada = parametros.get("tasa_llegada", {})
        tiempo_entre_llegadas = parametros.get("tiempo_entre_llegadas", {})
        tasa_servicio_por_servidor = parametros.get("tasa_servicio_por_servidor", {})
        tiempo_servicio_por_servidor = parametros.get("tiempo_servicio_por_servidor", {})
        cantidad_servidores = parametros.get("cantidad_servidores", {})
        capacidad_sistema = parametros.get("capacidad_sistema", {})
        disciplina_cola = parametros.get("disciplina_cola", {})
        # poblacion = parametros.get("poblacion", {}) # Si tienes este parámetro

        # Llamar a las funciones auxiliares para poblar el documento 'doc'
        esPrimerSupuesto = _primer_supuesto(doc, tasa_llegada, tiempo_entre_llegadas)
        esSegundoSupuesto = _segundo_supuesto(doc, tasa_servicio_por_servidor, tiempo_servicio_por_servidor)
        
        esTercerSupuesto = False # Inicializar por si no se cumple la condición
        if esPrimerSupuesto and esSegundoSupuesto:
            esTercerSupuesto = _tercer_supuesto(doc, esPrimerSupuesto, esSegundoSupuesto) # Llama a la función
            # CORRECCIÓN: La condición debe usar la variable booleana retornada
            if esTercerSupuesto: # Usar la variable que guarda el resultado
                _cuarto_supuesto(doc, esTercerSupuesto)
        
        # Lógica para "NO proceso nacimiento muerte"
        if esPrimerSupuesto is False or esSegundoSupuesto is False:
            doc.add_heading("NO proceso nacimiento muerte", level=1)
            doc.add_paragraph("✓ Enunciado 1") # Asumo que esto es un placeholder y debería ser dinámico
            doc.add_paragraph("✓ Es un tema más avanzado que no podrá solucionarse con este programa.")
            if _poblacion_finita(doc): # Si no necesita parámetros específicos o los toma de otro lado
                doc.add_heading("Supuestos de Enunciados Distintos", level=1)
                doc.add_paragraph("✓ Enunciado 1") # Asumo que esto es un placeholder y debería ser dinámico
                doc.add_paragraph("✓ Es un tema más avanzado que no podrá solucionarse con este programa.")
                return False
            return False

        _quinto_supuesto(doc, cantidad_servidores)
        _sexto_supuesto(doc, capacidad_sistema)
        _disciplina_cola(doc, disciplina_cola)

        
        # Guardar el documento
        docs_dir_abs = os.path.join(project_root_dir, "docs")
        if not os.path.exists(docs_dir_abs):
            os.makedirs(docs_dir_abs, exist_ok=True)
            print(f"Directorio '{docs_dir_abs}' creado.")
        
        ruta_word = os.path.join(docs_dir_abs, nombre_archivo_word)
        doc.save(ruta_word)
        
        print(f"Texto guardado en: {ruta_word}")
        return True
    except PermissionError:
        print(f"No se pudo guardar el documento. Verifica si el archivo '{ruta_word}' está abierto.")
        return False
    except Exception as e:
        print(f"Error al generar o guardar el documento Word '{nombre_archivo_word}': {e}")
        import traceback
        traceback.print_exc() # Imprimir el traceback completo para más detalles
        return False