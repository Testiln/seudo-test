from PIL import Image, ImageEnhance

def preprocesar_imagen(ruta_imagen):
    try:
        imagen = Image.open(ruta_imagen)
        imagen = imagen.convert('L')
        imagen = imagen.resize((imagen.width * 2, imagen.height * 2))
        enhancer = ImageEnhance.Contrast(imagen)
        imagen = enhancer.enhance(2)
        imagen = imagen.point(lambda x: 255 if x > 138 else 0, '1')
        return imagen
    except FileNotFoundError:
        print(f"Error: No se pudo encontrar: '{ruta_imagen}'")
        return None
    except Image.UnidentifiedImageError:
        print(f"Error: Archivo en '{ruta_imagen}' no es imagen válida.")
        return None
    except Exception as e: 
        print(f"Error al preprocesar '{ruta_imagen}': {e}")
        return None